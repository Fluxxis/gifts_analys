# Gift Arbitrage Bot MVP

Telegram бот для анализа NFT Gifts. Бот ищет лоты в диапазоне цены, считает риск, прибыль, скорость продажи, строит PNG график и дает ссылку на ручную покупку.

## Что уже реализовано

- aiogram 3 бот
- MRKT WebApp auth через Pyrogram и tgWebAppData
- MRKT `/gifts/saling`
- ввод диапазона цены
- inline карточки сделок
- SQLite база
- snapshots цен
- попытка сбора feed/sales, если endpoint доступен
- расчет прибыли, риска и confidence score
- PNG график цены
- watchlist
- админка статуса
- запуск на Ubuntu через start.sh и systemd

## Что честно не реализовано в MVP

- Автопокупка
- Автовыставление на продажу
- Полная интеграция Tonnel и Portals

Tonnel и Portals добавлены как адаптеры not_configured. Они не ломают бота. Для реальной работы нужно добавить их authData и методы конкретной библиотеки.

## Установка Ubuntu

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip git
chmod +x install.sh start.sh
./install.sh
nano config.json
./start.sh
```

## Настройка config.json

Заполни:

```json
"bot_token": "TOKEN_FROM_BOTFATHER",
"admin_ids": [7225974704],
"telegram_user": {
  "api_id": 123456,
  "api_hash": "YOUR_API_HASH",
  "session_name": "./data/sessions/market_user"
}
```

api_id и api_hash берутся на my.telegram.org.

При первом запуске Pyrogram попросит войти в Telegram аккаунт. Это нужно для MRKT Mini App авторизации.

Проверить MRKT токен отдельно:

```bash
./venv/bin/python scripts/generate_mrkt_token.py
```

## Systemd

Если проект лежит в `/opt/gift_arbitrage_bot`:

```bash
sudo cp gift_bot.service /etc/systemd/system/gift_bot.service
sudo systemctl daemon-reload
sudo systemctl enable gift_bot
sudo systemctl start gift_bot
sudo systemctl status gift_bot
journalctl -u gift_bot -f
```

## Команды в боте

- `/start` — меню
- кнопка `Найти выгодные гифты` — поиск
- кнопка `Watchlist` — создать правило отслеживания
- кнопка `Админка` — статус, только admin_ids

## Важно

Бот не обещает 100% прибыль. Он считает оценку по данным. Если нет истории продаж, бот снижает confidence score и пишет слабый вердикт. Это правильно. Иначе бот будет покупать неликвид по фейковому floor.

## Исправление 1.0.1-fixed

- Убран краш Telegram `message is not modified` при повторном нажатии на ту же inline-кнопку.
- Добавлен общий helper `app/bot/safe_edit.py`.
- Все `callback.message.edit_text(...)` в обработчиках заменены на безопасное редактирование.
- Добавлен `config.example.json`, чтобы `install.sh` не падал, если `config.json` отсутствует.

## Fix 2026-05-18 v2

Исправлено:

1. `TelegramBadRequest: message is not modified`
   - Все редактирования сообщений идут через `app/bot/safe_edit.py`.
   - Повторный клик по той же inline-кнопке больше не должен ронять обработчик.

2. `MRKT HTTP 429 if you need more rps`
   - Добавлен throttling запросов к MRKT.
   - Добавлена пауза после HTTP 429.
   - Добавлен кэш floor-цен.
   - Сканер больше не запрашивает floor/sales для каждого лота подряд.
   - Уменьшены дефолтные лимиты скана: 2 страницы по 30 лотов.

Важно:

MRKT ограничивает частоту запросов. Если вручную спамить кнопку поиска или держать много watchlist-правил, API всё равно может вернуть 429. Бот теперь не должен падать, но точность анализа временно падает, пока MRKT держит cooldown.

## Обновление v3

- Добавлен прогресс анализа в Telegram: процент, шаг и примерное время до выдачи карточек.
- Добавлена кнопка «Своя цена» в главное меню.
- Свой диапазон теперь вводится одним сообщением: `10-15`, `10 15`, `10 до 15`.
- Одно число, например `20`, означает поиск от `0` до `20 TON`.

