#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p data/logs data/charts data/sessions
source venv/bin/activate
python -m app.main 2>&1 | tee -a data/logs/bot.log
