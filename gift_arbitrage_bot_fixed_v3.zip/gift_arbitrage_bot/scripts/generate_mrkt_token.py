from __future__ import annotations

import asyncio
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app.config import load_config
from app.auth.mrkt_auth import get_mrkt_token


async def main() -> None:
    config = load_config(ROOT / "config.json")
    token = await get_mrkt_token(config)
    print("MRKT token получен. Не публикуй его.")
    print(token)
    path = ROOT / "data" / "mrkt_token.txt"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(token, encoding="utf-8")
    print(f"Сохранено: {path}")


if __name__ == "__main__":
    asyncio.run(main())
