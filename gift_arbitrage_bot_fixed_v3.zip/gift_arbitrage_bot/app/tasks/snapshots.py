from __future__ import annotations

# Snapshot writing is done in Database.save_listings during scans.
