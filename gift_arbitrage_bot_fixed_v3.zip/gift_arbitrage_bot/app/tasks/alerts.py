from __future__ import annotations

import asyncio
import logging
from aiogram import Bot

from app.bot.texts import deal_card_text
from app.bot.keyboards import deal_keyboard
from app.db import Database
from app.tasks.scanner import ScanEngine

logger = logging.getLogger(__name__)


async def watchlist_loop(bot: Bot, db: Database, scanner: ScanEngine, interval: int) -> None:
    while True:
        try:
            items = await db.list_watchlist(enabled_only=True)
            for item in items:
                results = await scanner.scan(
                    user_id=int(item["user_id"]),
                    min_price=float(item["min_price"]),
                    max_price=float(item["max_price"]),
                    market=str(item.get("market") or "all"),
                    strategy=str(item.get("strategy") or "balance"),
                    max_risk=str(item.get("max_risk") or "medium"),
                    collection=item.get("collection"),
                    model=item.get("model"),
                    min_profit_percent=float(item.get("min_profit_percent") or 8.0),
                    save_deals=True,
                )
                for deal_id, deal in results[:2]:
                    if deal_id is None:
                        continue
                    if deal.verdict == "пропустить":
                        continue
                    sale_key = f"{deal.listing.market}:{deal.listing.sale_id or deal.listing.gift_id}"
                    is_new = await db.mark_alert_sent(int(item["user_id"]), sale_key)
                    if not is_new:
                        continue
                    await bot.send_message(
                        int(item["user_id"]),
                        "🚨 Найден лот из watchlist\n\n" + deal_card_text(deal_id, deal),
                        reply_markup=deal_keyboard(deal_id, deal.listing.link),
                    )
                    await asyncio.sleep(0.2)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.exception("watchlist loop failed")
            await db.log_error("watchlist_loop", str(exc))
        await asyncio.sleep(max(20, interval))
