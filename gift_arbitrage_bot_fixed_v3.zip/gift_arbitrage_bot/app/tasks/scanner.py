from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from typing import Any

from app.analyzer.deal_score import sort_key
from app.analyzer.profit import analyze_listing
from app.analyzer.risk import risk_allowed
from app.config import AppConfig
from app.db import Database
from app.markets.base import DealAnalysis, MarketAdapter
from app.markets.mrkt import MrktMarket
from app.markets.portals import PortalsMarket
from app.markets.tonnel import TonnelMarket

logger = logging.getLogger(__name__)

ProgressCallback = Callable[[int, int, str], Awaitable[None]]


async def _progress(progress: ProgressCallback | None, current: int, total: int, detail: str) -> None:
    if progress is None:
        return
    try:
        await progress(current, total, detail)
    except Exception as exc:
        logger.debug("progress update failed: %s", exc)


class ScanEngine:
    def __init__(self, config: AppConfig, db: Database) -> None:
        self.config = config
        self.db = db
        self.markets: dict[str, MarketAdapter] = {
            "mrkt": MrktMarket(config),
            "tonnel": TonnelMarket(config),
            "portals": PortalsMarket(config),
        }

    async def close(self) -> None:
        for adapter in self.markets.values():
            try:
                await adapter.close()
            except Exception as exc:
                logger.warning("Close market %s failed: %s", adapter.name, exc)

    async def status(self) -> list[dict[str, Any]]:
        result = []
        for adapter in self.markets.values():
            try:
                result.append(await adapter.status())
            except Exception as exc:
                result.append({"market": adapter.name, "status": "error", "error": str(exc)})
        return result

    def _selected_markets(self, market: str) -> list[MarketAdapter]:
        if market != "all":
            adapter = self.markets.get(market)
            return [adapter] if adapter else []
        return list(self.markets.values())

    async def scan(
        self,
        *,
        user_id: int,
        min_price: float,
        max_price: float,
        market: str = "all",
        strategy: str = "balance",
        max_risk: str = "medium",
        collection: str | None = None,
        model: str | None = None,
        min_profit_percent: float | None = None,
        save_deals: bool = True,
        progress: ProgressCallback | None = None,
    ) -> list[tuple[int | None, DealAnalysis]]:
        selected = self._selected_markets(market)
        enrich_limit = max(0, int(getattr(self.config.scan, "enrich_limit_per_scan", 4)))
        total_steps = max(5, len(selected) + enrich_limit + 4)
        step = 0

        await _progress(progress, step, total_steps, "проверяю выбранные маркеты")

        active_selected: list[MarketAdapter] = []
        listings = []
        for index, adapter in enumerate(selected, start=1):
            try:
                await _progress(progress, step, total_steps, f"запрашиваю {adapter.name.upper()} ({index}/{len(selected)})")
                status = await adapter.status()
                if status.get("status") in {"disabled", "not_configured", "adapter_stub"} and adapter.name != "mrkt":
                    step += 1
                    await _progress(progress, step, total_steps, f"{adapter.name.upper()} пропущен")
                    continue
                active_selected.append(adapter)
                items = await adapter.search_listings(
                    min_price=min_price,
                    max_price=max_price,
                    collection=collection,
                    model=model,
                    limit=self.config.scan.max_pages_per_scan * self.config.scan.items_per_page,
                )
                listings.extend(items)
                await self.db.save_listings(items)
                step += 1
                await _progress(progress, step, total_steps, f"{adapter.name.upper()} готов. Лотов собрано: {len(listings)}")
            except Exception as exc:
                step += 1
                logger.exception("scan %s failed", adapter.name)
                await self.db.log_error(f"scan:{adapter.name}", str(exc))
                await _progress(progress, step, total_steps, f"{adapter.name.upper()} дал ошибку, продолжаю")

        analyses: list[DealAnalysis] = []
        seen_keys: set[str] = set()
        enriched_types: set[tuple[str, str, str]] = set()

        await _progress(progress, step, total_steps, f"собрано лотов: {len(listings)}. Проверяю историю продаж")

        for listing in listings:
            key = f"{listing.market}:{listing.sale_id or listing.gift_id}"
            if key in seen_keys:
                continue
            seen_keys.add(key)

            # Не дергаем MRKT по каждому лоту. Это была главная причина HTTP 429.
            # Обогащаем только несколько уникальных collection/model за один скан,
            # а дальше используем уже сохраненные floor/sales из SQLite.
            listing_model = listing.model or ""
            for adapter in active_selected:
                enrich_key = (adapter.name, listing.collection.lower(), listing_model.lower())
                if enrich_key in enriched_types:
                    continue
                if len(enriched_types) >= enrich_limit:
                    continue
                enriched_types.add(enrich_key)
                try:
                    sales = await adapter.get_sales_history(collection=listing.collection, model=listing.model, limit=80)
                    if sales:
                        await self.db.save_sale_records(sales)
                except Exception as exc:
                    logger.debug("sales history failed %s: %s", adapter.name, exc)
                try:
                    floors = await adapter.get_floor_prices(collection=listing.collection, model=listing.model)
                    if floors:
                        await self.db.save_floor_records(floors)
                except Exception as exc:
                    logger.debug("floor failed %s: %s", adapter.name, exc)

                step = min(step + 1, max(1, total_steps - 3))
                await _progress(
                    progress,
                    step,
                    total_steps,
                    f"проверяю историю и floor: {len(enriched_types)}/{enrich_limit}",
                )

            sales_rows = await self.db.get_recent_sales(listing.collection, listing.model, hours=168)
            floor_rows = await self.db.get_latest_floors(listing.collection, listing.model)
            deal = analyze_listing(listing, sales_rows=sales_rows, floor_rows=floor_rows, config=self.config.analysis)
            if min_profit_percent is not None and (deal.profit_percent is None or deal.profit_percent < min_profit_percent):
                if deal.confidence_score < 45:
                    continue
            analyses.append(deal)

        await _progress(progress, max(step, total_steps - 3), total_steps, f"считаю прибыль и риск. Лотов: {len(analyses)}")

        analyses.sort(key=lambda d: sort_key(d, strategy), reverse=True)
        filtered = [d for d in analyses if risk_allowed(d.risk_level, max_risk) or d.confidence_score >= 45]
        results = filtered[: max(1, self.config.ui.results_per_page)]

        await _progress(progress, total_steps - 2, total_steps, f"отбираю лучшие варианты: {len(results)}")

        saved: list[tuple[int | None, DealAnalysis]] = []
        for deal in results:
            deal_id = await self.db.save_deal(user_id, deal) if save_deals else None
            saved.append((deal_id, deal))

        await _progress(progress, total_steps - 1, total_steps, "сохраняю результаты и готовлю карточки")
        return saved
