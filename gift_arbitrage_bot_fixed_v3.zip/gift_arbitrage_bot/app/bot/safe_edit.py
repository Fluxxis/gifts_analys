from __future__ import annotations

from typing import Any

from aiogram.exceptions import TelegramBadRequest
from aiogram.types import InlineKeyboardMarkup, Message


_NOT_MODIFIED_TEXT = "message is not modified"


async def safe_edit_text(
    message: Message | None,
    text: str,
    reply_markup: InlineKeyboardMarkup | None = None,
    **kwargs: Any,
) -> bool:
    """Edit a Telegram message without crashing on duplicate content.

    Telegram rejects edit requests when the new text and inline keyboard are exactly
    the same as the current message. This helper treats that case as a successful
    no-op and lets the callback handler answer normally.
    """
    if message is None:
        return False

    try:
        await message.edit_text(text, reply_markup=reply_markup, **kwargs)
        return True
    except TelegramBadRequest as exc:
        if _NOT_MODIFIED_TEXT in str(exc).lower():
            return False
        raise
