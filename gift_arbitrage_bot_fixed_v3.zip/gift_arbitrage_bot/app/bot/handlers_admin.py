from __future__ import annotations

from aiogram import F, Router
from aiogram.types import CallbackQuery

from app.bot.keyboards import admin_keyboard
from app.bot.safe_edit import safe_edit_text
from app.config import AppConfig
from app.db import Database
from app.tasks.scanner import ScanEngine

router = Router()


def _is_admin(user_id: int, config: AppConfig) -> bool:
    return user_id in config.admin_ids


@router.callback_query(F.data == "admin:status")
async def admin_status(callback: CallbackQuery, config: AppConfig, db: Database, scanner: ScanEngine) -> None:
    if not _is_admin(callback.from_user.id, config):
        await callback.answer("Нет доступа", show_alert=True)
        return
    stats = await db.stats()
    markets = await scanner.status()
    market_text = "\n".join(f"{m.get('market')}: {m.get('status')}" for m in markets)
    text = (
        "🛠 Админка\n\n"
        f"Listings: {stats.get('listings')}\n"
        f"Snapshots: {stats.get('snapshots')}\n"
        f"Sales: {stats.get('sales_history')}\n"
        f"Deals: {stats.get('deals_found')}\n"
        f"Watchlist: {stats.get('watchlist')}\n"
        f"Errors: {stats.get('errors')}\n"
        f"Последний скан: {stats.get('last_scan') or 'нет'}\n\n"
        f"Маркеты:\n{market_text}"
    )
    await safe_edit_text(callback.message, text, reply_markup=admin_keyboard())
    await callback.answer()


@router.callback_query(F.data == "admin:errors")
async def admin_errors(callback: CallbackQuery, config: AppConfig, db: Database) -> None:
    if not _is_admin(callback.from_user.id, config):
        await callback.answer("Нет доступа", show_alert=True)
        return
    rows = await db.fetchall("SELECT * FROM errors ORDER BY created_at DESC LIMIT 10")
    if not rows:
        text = "Ошибок нет."
    else:
        text = "Последние ошибки:\n\n" + "\n\n".join(f"{r['created_at']} | {r['source']}\n{r['message']}" for r in rows)
    await safe_edit_text(callback.message, text, reply_markup=admin_keyboard())
    await callback.answer()
