from __future__ import annotations

from pathlib import Path

from aiogram import F, Router
from aiogram.types import CallbackQuery, FSInputFile

from app.bot.keyboards import chart_keyboard, deal_keyboard
from app.bot.texts import deal_details_text
from app.charts.price_chart import build_price_chart
from app.config import AppConfig
from app.db import Database

router = Router()


@router.callback_query(F.data == "deal:hide")
async def hide_deal(callback: CallbackQuery) -> None:
    await callback.message.delete()
    await callback.answer()


@router.callback_query(F.data.startswith("deal:details:"))
async def deal_details(callback: CallbackQuery, db: Database) -> None:
    deal_id = int(str(callback.data).split(":")[-1])
    row = await db.get_deal(deal_id)
    if not row:
        await callback.answer("Сделка не найдена", show_alert=True)
        return
    await callback.message.answer(deal_details_text(row), reply_markup=deal_keyboard(deal_id, row.get("link") or "https://t.me/mrkt/app"))
    await callback.answer()


@router.callback_query(F.data.startswith("deal:chart:"))
async def deal_chart(callback: CallbackQuery, db: Database, config: AppConfig) -> None:
    deal_id = int(str(callback.data).split(":")[-1])
    row = await db.get_deal(deal_id)
    if not row:
        await callback.answer("Сделка не найдена", show_alert=True)
        return
    snapshots = await db.get_recent_snapshots(str(row.get("collection")), row.get("model"), hours=168)
    floors = await db.get_latest_floors(str(row.get("collection")), row.get("model"))
    path = Path(config.charts_path) / f"deal_{deal_id}_price.png"
    build_price_chart(deal=row, snapshots=snapshots, floors=floors, output_path=path)
    await db.cache_chart(deal_id, "price", str(path))
    caption = (
        f"📈 График сделки\n"
        f"Цена покупки: {row.get('buy_price'):.3f} TON\n"
        f"Ожидаемая продажа: {row.get('expected_sell_price') or 'нет данных'}\n"
        f"Риск: {row.get('risk_level')}\n"
        f"Надежность: {row.get('confidence_score')}/100"
    )
    await callback.message.answer_photo(
        FSInputFile(path),
        caption=caption,
        reply_markup=chart_keyboard(deal_id, row.get("link") or "https://t.me/mrkt/app"),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("deal:watch:"))
async def deal_watch(callback: CallbackQuery, db: Database, config: AppConfig) -> None:
    deal_id = int(str(callback.data).split(":")[-1])
    row = await db.get_deal(deal_id)
    if not row:
        await callback.answer("Сделка не найдена", show_alert=True)
        return
    await db.add_watchlist(
        {
            "user_id": callback.from_user.id,
            "min_price": max(0.0, float(row.get("buy_price") or 0) * 0.9),
            "max_price": float(row.get("buy_price") or 0) * 1.05,
            "market": row.get("market") or "all",
            "collection": row.get("collection"),
            "model": row.get("model"),
            "symbol": row.get("symbol"),
            "backdrop": row.get("backdrop"),
            "min_profit_percent": config.analysis.min_profit_percent,
            "max_risk": "medium",
            "strategy": "balance",
        }
    )
    await callback.answer("Добавлено в watchlist", show_alert=True)


@router.callback_query(F.data.startswith("deal:refresh:"))
async def refresh_deal(callback: CallbackQuery) -> None:
    await callback.answer("Обновление отдельной сделки будет в версии 2. Запусти новый поиск по тому же диапазону.", show_alert=True)
