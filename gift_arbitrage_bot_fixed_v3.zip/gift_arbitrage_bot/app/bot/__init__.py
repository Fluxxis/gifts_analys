from app.bot.handlers_start import router as start_router
from app.bot.handlers_scan import router as scan_router
from app.bot.handlers_deals import router as deals_router
from app.bot.handlers_watchlist import router as watchlist_router
from app.bot.handlers_admin import router as admin_router

routers = [start_router, scan_router, deals_router, watchlist_router, admin_router]
