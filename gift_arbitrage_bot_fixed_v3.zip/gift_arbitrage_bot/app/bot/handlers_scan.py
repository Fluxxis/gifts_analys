from __future__ import annotations

import time

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.bot.keyboards import deal_keyboard, market_keyboard, risk_keyboard, strategy_keyboard
from app.bot.safe_edit import safe_edit_text
from app.bot.texts import deal_card_text, scan_summary
from app.states import ScanStates
from app.tasks.scanner import ScanEngine
from app.utils.validators import parse_price, parse_price_range

router = Router()


def _progress_bar(current: int, total: int, width: int = 10) -> str:
    total = max(1, total)
    current = max(0, min(current, total))
    filled = round(width * current / total)
    return "█" * filled + "░" * (width - filled)


def _progress_text(
    *,
    min_price: float,
    max_price: float,
    market: str,
    max_risk: str,
    current: int,
    total: int,
    detail: str,
    started_at: float,
) -> str:
    total = max(1, total)
    current = max(0, min(current, total))
    percent = int(current * 100 / total)
    elapsed = max(0.1, time.monotonic() - started_at)
    if current <= 0:
        eta_text = "Примерно осталось: считаю."
    elif current >= total:
        eta_text = "Готовлю выдачу данных."
    else:
        left = int(max(1, elapsed / current * (total - current)))
        eta_text = f"Примерно осталось: {left} сек."

    return (
        "🔎 Анализирую рынок\n\n"
        f"Диапазон: {min_price:g}-{max_price:g} TON\n"
        f"Маркет: {market}\n"
        f"Риск: {max_risk}\n\n"
        f"{_progress_bar(current, total)} {percent}%\n"
        f"Шаг: {current}/{total}\n"
        f"{eta_text}\n"
        f"Сейчас: {detail}"
    )


@router.callback_query(F.data == "scan:custom")
async def custom_price(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await state.set_state(ScanStates.waiting_price_range)
    await safe_edit_text(
        callback.message,
        "Введи свою цену или диапазон.\n\n"
        "Примеры:\n"
        "10-15 — искать от 10 до 15 TON\n"
        "10 15 — то же самое\n"
        "20 — искать от 0 до 20 TON",
    )
    await callback.answer()


@router.callback_query(F.data.startswith("scan:preset:"))
async def preset_price(callback: CallbackQuery, state: FSMContext) -> None:
    parts = str(callback.data).split(":")
    min_price = float(parts[2])
    max_price = float(parts[3])
    await state.update_data(min_price=min_price, max_price=max_price)
    await state.set_state(ScanStates.waiting_market)
    await safe_edit_text(callback.message, f"Диапазон: {min_price:g}-{max_price:g} TON. Выбери маркет.", reply_markup=market_keyboard("scan"))
    await callback.answer()


@router.message(ScanStates.waiting_price_range)
async def input_price_range(message: Message, state: FSMContext) -> None:
    try:
        min_price, max_price = parse_price_range(message.text or "")
    except Exception:
        await message.answer("Введи нормальный диапазон. Пример: 10-15 или 10 15. Одно число, например 20, означает 0-20 TON.")
        return

    await state.update_data(min_price=min_price, max_price=max_price)
    await state.set_state(ScanStates.waiting_market)
    await message.answer(f"Диапазон: {min_price:g}-{max_price:g} TON. Выбери маркет.", reply_markup=market_keyboard("scan"))


@router.message(ScanStates.waiting_min_price)
async def input_min_price(message: Message, state: FSMContext) -> None:
    try:
        price = parse_price(message.text or "")
    except Exception:
        await message.answer("Введи число. Пример: 10")
        return
    await state.update_data(min_price=price)
    await state.set_state(ScanStates.waiting_max_price)
    await message.answer("Введи цену до. Пример: 15")


@router.message(ScanStates.waiting_max_price)
async def input_max_price(message: Message, state: FSMContext) -> None:
    try:
        max_price = parse_price(message.text or "")
    except Exception:
        await message.answer("Введи число. Пример: 15")
        return
    data = await state.get_data()
    min_price = float(data.get("min_price") or 0)
    if max_price <= min_price:
        await message.answer("Цена до должна быть больше цены от.")
        return
    await state.update_data(max_price=max_price)
    await state.set_state(ScanStates.waiting_market)
    await message.answer(f"Диапазон: {min_price:g}-{max_price:g} TON. Выбери маркет.", reply_markup=market_keyboard("scan"))


@router.callback_query(ScanStates.waiting_market, F.data.startswith("scan:market:"))
async def choose_market(callback: CallbackQuery, state: FSMContext) -> None:
    market = str(callback.data).split(":")[-1]
    await state.update_data(market=market)
    await state.set_state(ScanStates.waiting_strategy)
    await safe_edit_text(callback.message, "Выбери стратегию сортировки.", reply_markup=strategy_keyboard("scan"))
    await callback.answer()


@router.callback_query(ScanStates.waiting_strategy, F.data.startswith("scan:strategy:"))
async def choose_strategy(callback: CallbackQuery, state: FSMContext) -> None:
    strategy = str(callback.data).split(":")[-1]
    await state.update_data(strategy=strategy)
    await state.set_state(ScanStates.waiting_risk)
    await safe_edit_text(callback.message, "Выбери максимальный риск.", reply_markup=risk_keyboard("scan"))
    await callback.answer()


@router.callback_query(ScanStates.waiting_risk, F.data.startswith("scan:risk:"))
async def choose_risk(callback: CallbackQuery, state: FSMContext, scanner: ScanEngine) -> None:
    max_risk = str(callback.data).split(":")[-1]
    await state.update_data(max_risk=max_risk)
    data = await state.get_data()
    await state.clear()
    min_price = float(data["min_price"])
    max_price = float(data["max_price"])
    market = str(data.get("market") or "all")
    strategy = str(data.get("strategy") or "balance")
    started_at = time.monotonic()
    last_progress_at = 0.0
    last_progress_payload: tuple[int, int, str] | None = None

    async def progress(current: int, total: int, detail: str) -> None:
        nonlocal last_progress_at, last_progress_payload
        now = time.monotonic()
        payload = (current, total, detail)
        if payload == last_progress_payload:
            return
        if current < total and now - last_progress_at < 1.1:
            return
        last_progress_at = now
        last_progress_payload = payload
        await safe_edit_text(
            callback.message,
            _progress_text(
                min_price=min_price,
                max_price=max_price,
                market=market,
                max_risk=max_risk,
                current=current,
                total=total,
                detail=detail,
                started_at=started_at,
            ),
        )

    await progress(0, 5, "запускаю сбор лотов")
    await callback.answer()
    results = await scanner.scan(
        user_id=callback.from_user.id,
        min_price=min_price,
        max_price=max_price,
        market=market,
        strategy=strategy,
        max_risk=max_risk,
        save_deals=True,
        progress=progress,
    )
    await progress(5, 5, f"готово, найдено вариантов: {len(results)}")
    await callback.message.answer(scan_summary(len(results)))
    for deal_id, deal in results:
        await callback.message.answer(deal_card_text(deal_id, deal), reply_markup=deal_keyboard(deal_id, deal.listing.link))
