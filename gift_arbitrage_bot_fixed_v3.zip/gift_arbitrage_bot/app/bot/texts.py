from __future__ import annotations

from typing import Any

from app.markets.base import DealAnalysis
from app.utils.money import fmt_percent, fmt_ton
from app.utils.time import human_duration


def start_text() -> str:
    return (
        "Бот для анализа NFT Gifts.\n\n"
        "Выбираешь диапазон цены, например 10-15 TON. "
        "Бот собирает лоты, строит график, считает прибыль, риск и примерное время продажи.\n\n"
        "Автопокупки в MVP нет. Сначала анализ и ручная покупка. Это правильнее."
    )


def deal_card_text(deal_id: int | None, deal: DealAnalysis) -> str:
    listing = deal.listing
    title = listing.collection
    if listing.model:
        title += f" / {listing.model}"
    if listing.number:
        title += f" #{listing.number}"
    reasons = "\n".join(f"• {x}" for x in deal.reasons[:3])
    return (
        f"🎁 {title}\n"
        f"Маркет: {listing.market.upper()}\n"
        f"Цена покупки: {fmt_ton(deal.buy_price)}\n"
        f"Быстрая продажа: {fmt_ton(deal.quick_sell_price)}\n"
        f"Нормальная продажа: {fmt_ton(deal.normal_sell_price)}\n"
        f"Жадная продажа: {fmt_ton(deal.greedy_sell_price)}\n\n"
        f"Чистая прибыль: {fmt_ton(deal.net_profit_ton)}\n"
        f"Доходность: {fmt_percent(deal.profit_percent)}\n"
        f"Продаж за 24ч: {deal.sales_24h}\n"
        f"Продаж за 7д: {deal.sales_7d}\n"
        f"Обычное время продажи: {human_duration(deal.median_time_to_sell_seconds)}\n"
        f"Риск: {deal.risk_level}\n"
        f"Надежность данных: {deal.confidence_score}/100\n\n"
        f"Вердикт: {deal.verdict}\n"
        f"Причины:\n{reasons}"
    )


def deal_details_text(row: dict[str, Any]) -> str:
    reasons = row.get("reasons") or []
    reasons_text = "\n".join(f"• {x}" for x in reasons) if reasons else "нет данных"
    return (
        f"📋 Подробно\n\n"
        f"Коллекция: {row.get('collection')}\n"
        f"Модель: {row.get('model') or 'нет данных'}\n"
        f"Символ: {row.get('symbol') or 'нет данных'}\n"
        f"Фон: {row.get('backdrop') or 'нет данных'}\n"
        f"Номер: {row.get('number') or 'нет данных'}\n"
        f"Маркет: {str(row.get('market')).upper()}\n\n"
        f"Цена покупки: {fmt_ton(row.get('buy_price'))}\n"
        f"Ожидаемая продажа: {fmt_ton(row.get('expected_sell_price'))}\n"
        f"Быстрая продажа: {fmt_ton(row.get('quick_sell_price'))}\n"
        f"Нормальная продажа: {fmt_ton(row.get('normal_sell_price'))}\n"
        f"Жадная продажа: {fmt_ton(row.get('greedy_sell_price'))}\n"
        f"Комиссия: {fmt_ton(row.get('fees_ton'))}\n"
        f"Чистая прибыль: {fmt_ton(row.get('net_profit_ton'))}\n"
        f"Доходность: {fmt_percent(row.get('profit_percent'))}\n\n"
        f"Продаж за 24ч: {row.get('sales_24h')}\n"
        f"Продаж за 7д: {row.get('sales_7d')}\n"
        f"Среднее время продажи: {human_duration(row.get('avg_time_to_sell_seconds'))}\n"
        f"Медианное время продажи: {human_duration(row.get('median_time_to_sell_seconds'))}\n\n"
        f"Риск: {row.get('risk_level')}\n"
        f"Надежность: {row.get('confidence_score')}/100\n"
        f"Вердикт: {row.get('verdict')}\n\n"
        f"Причины:\n{reasons_text}"
    )


def scan_summary(count: int) -> str:
    if count == 0:
        return "Ничего нормального не найдено. Либо диапазон узкий, либо данных мало, либо MRKT auth не работает."
    return f"Найдено вариантов: {count}. Ниже лучшие по выбранной стратегии."
