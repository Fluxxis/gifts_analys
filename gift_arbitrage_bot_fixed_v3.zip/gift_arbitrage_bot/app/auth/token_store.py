from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass(slots=True)
class TokenInfo:
    token: str
    updated_at: datetime | None = None
    status: str = "unknown"


class InMemoryTokenStore:
    def __init__(self) -> None:
        self._tokens: dict[str, TokenInfo] = {}

    def get(self, market: str) -> TokenInfo | None:
        return self._tokens.get(market)

    def set(self, market: str, token: str, updated_at: datetime | None = None, status: str = "ok") -> None:
        self._tokens[market] = TokenInfo(token=token, updated_at=updated_at, status=status)
