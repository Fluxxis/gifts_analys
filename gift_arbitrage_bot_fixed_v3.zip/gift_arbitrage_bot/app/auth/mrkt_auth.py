from __future__ import annotations

import logging
from urllib.parse import unquote

import aiohttp

from app.config import AppConfig

logger = logging.getLogger(__name__)


class MrktAuthError(RuntimeError):
    pass


async def get_mrkt_init_data(config: AppConfig) -> str:
    try:
        from pyrogram import Client
        from pyrogram.raw.functions.messages import RequestAppWebView
        from pyrogram.raw.types import InputBotAppShortName, InputPeerUser, InputUser
    except Exception as exc:
        raise MrktAuthError("Pyrogram не установлен. Установи requirements.txt.") from exc

    api_id = config.telegram_user.api_id
    api_hash = config.telegram_user.api_hash
    session_name = config.telegram_user.session_name
    if not api_id or not api_hash:
        raise MrktAuthError("api_id и api_hash не заполнены в config.json")

    client = Client(session_name, api_id=api_id, api_hash=api_hash)
    async with client:
        resolved_bot = await client.resolve_peer(config.markets.mrkt.bot_username)
        if not isinstance(resolved_bot, InputPeerUser):
            raise MrktAuthError(f"Не удалось получить InputPeerUser для @{config.markets.mrkt.bot_username}")
        bot = InputUser(user_id=resolved_bot.user_id, access_hash=resolved_bot.access_hash)
        bot_app = InputBotAppShortName(bot_id=bot, short_name=config.markets.mrkt.app_short_name)
        web_view = await client.invoke(
            RequestAppWebView(
                peer=resolved_bot,
                app=bot_app,
                platform=config.markets.mrkt.platform,
            )
        )
        url = web_view.url
        if "tgWebAppData=" not in url:
            raise MrktAuthError("MRKT WebApp URL не содержит tgWebAppData")
        return unquote(url.split("tgWebAppData=", 1)[1].split("&tgWebAppVersion", 1)[0])


async def get_mrkt_token(config: AppConfig) -> str:
    if config.markets.mrkt.token:
        return config.markets.mrkt.token
    init_data = await get_mrkt_init_data(config)
    auth_url = f"{config.markets.mrkt.base_url.rstrip('/')}/auth"
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=config.scan.request_timeout_seconds)) as session:
        async with session.post(auth_url, json={"data": init_data}) as response:
            try:
                data = await response.json(content_type=None)
            except Exception as exc:
                text = await response.text()
                raise MrktAuthError(f"MRKT /auth вернул не JSON. HTTP {response.status}. Ответ: {text[:500]}") from exc
            if response.status != 200:
                raise MrktAuthError(f"MRKT /auth ошибка HTTP {response.status}. Ответ: {data}")
            token = data.get("token") or data.get("accessToken") or data.get("access_token")
            if not token:
                raise MrktAuthError("MRKT /auth не вернул token")
            logger.info("MRKT token обновлен")
            return str(token)
