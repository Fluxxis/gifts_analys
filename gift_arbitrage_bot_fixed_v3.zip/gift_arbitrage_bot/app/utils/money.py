from __future__ import annotations

from decimal import Decimal, InvalidOperation


def to_float(value, default: float | None = None) -> float | None:
    if value is None:
        return default
    try:
        if isinstance(value, str):
            value = value.replace(",", ".").strip()
            if value == "":
                return default
        return float(Decimal(str(value)))
    except (InvalidOperation, ValueError, TypeError):
        return default


def normalize_ton_price(value) -> float | None:
    price = to_float(value)
    if price is None:
        return None
    # MRKT sometimes returns nanoTON values. Keep direct TON values as-is.
    if price >= 1_000_000:
        price = price / 1_000_000_000
    return round(price, 9)


def fmt_ton(value: float | None, decimals: int = 3) -> str:
    if value is None:
        return "нет данных"
    return f"{value:.{decimals}f} TON"


def fmt_percent(value: float | None) -> str:
    if value is None:
        return "нет данных"
    return f"{value:.2f}%"
