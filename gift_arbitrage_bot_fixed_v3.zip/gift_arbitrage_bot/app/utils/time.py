from __future__ import annotations

from datetime import datetime, timezone


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return now_utc().isoformat()


def parse_dt(value: str | None):
    if not value:
        return None
    try:
        if value.endswith("Z"):
            value = value[:-1] + "+00:00"
        dt = datetime.fromisoformat(value)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def human_duration(seconds: int | None) -> str:
    if seconds is None or seconds < 0:
        return "нет данных"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}м"
    hours = minutes // 60
    rem_minutes = minutes % 60
    if hours < 24:
        return f"{hours}ч {rem_minutes}м" if rem_minutes else f"{hours}ч"
    days = hours // 24
    rem_hours = hours % 24
    return f"{days}д {rem_hours}ч" if rem_hours else f"{days}д"
