from __future__ import annotations

import re


def parse_price(text: str) -> float:
    value = text.replace(",", ".").strip()
    price = float(value)
    if price < 0:
        raise ValueError("Цена не должна быть меньше 0")
    if price > 1_000_000:
        raise ValueError("Слишком большая цена")
    return price


def parse_price_range(text: str) -> tuple[float, float]:
    """Parse custom TON range.

    Supported examples:
    - 10-15
    - 10 15
    - 10 до 15
    - 12,5-18
    - 20  -> 0-20
    """
    raw = (text or "").strip().lower().replace(",", ".")
    numbers = re.findall(r"\d+(?:\.\d+)?", raw)
    if not numbers:
        raise ValueError("Не найдено число")

    if len(numbers) == 1:
        min_price = 0.0
        max_price = parse_price(numbers[0])
    else:
        min_price = parse_price(numbers[0])
        max_price = parse_price(numbers[1])

    if max_price <= min_price:
        raise ValueError("Цена до должна быть больше цены от")
    return min_price, max_price


def normalize_market(value: str) -> str:
    value = value.lower().strip()
    if value in {"all", "все", "all_markets"}:
        return "all"
    if value in {"mrkt", "tonnel", "portals"}:
        return value
    return "all"


def normalize_risk(value: str) -> str:
    value = value.lower().strip()
    if value in {"low", "medium", "high"}:
        return value
    return "medium"
