from __future__ import annotations

import json
from typing import Any

SENSITIVE_KEYS = {"token", "auth", "authdata", "tgwebappdata", "authorization", "api_hash", "phone", "session"}


def mask_secrets(data: Any) -> Any:
    if isinstance(data, dict):
        out = {}
        for key, value in data.items():
            lowered = str(key).lower()
            if any(s in lowered for s in SENSITIVE_KEYS):
                out[key] = "***"
            else:
                out[key] = mask_secrets(value)
        return out
    if isinstance(data, list):
        return [mask_secrets(x) for x in data]
    return data


def dumps_safe(data: Any) -> str:
    return json.dumps(mask_secrets(data), ensure_ascii=False, default=str)
