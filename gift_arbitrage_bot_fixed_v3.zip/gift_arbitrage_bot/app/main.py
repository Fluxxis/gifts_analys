from __future__ import annotations

import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from app.bot import routers
from app.config import load_config
from app.db import Database
from app.logging_config import setup_logging
from app.tasks.alerts import watchlist_loop
from app.tasks.scanner import ScanEngine

logger = logging.getLogger(__name__)


async def main() -> None:
    setup_logging()
    config = load_config()
    if not config.bot_token or config.bot_token == "PASTE_BOT_TOKEN":
        raise RuntimeError("Заполни bot_token в config.json")

    config.charts_path.mkdir(parents=True, exist_ok=True)
    config.db_path.parent.mkdir(parents=True, exist_ok=True)

    db = Database(config.db_path)
    await db.connect()
    scanner = ScanEngine(config, db)

    bot = Bot(token=config.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=MemoryStorage())
    for router in routers:
        dp.include_router(router)

    dp["config"] = config
    dp["db"] = db
    dp["scanner"] = scanner

    watch_task = asyncio.create_task(watchlist_loop(bot, db, scanner, config.scan.default_interval_seconds))
    try:
        logger.info("Bot started")
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        watch_task.cancel()
        try:
            await watch_task
        except asyncio.CancelledError:
            pass
        await scanner.close()
        await db.close()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
