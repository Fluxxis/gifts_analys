from __future__ import annotations

from app.markets.base import DealAnalysis


def sort_key(deal: DealAnalysis, strategy: str = "balance") -> tuple[float, float, float]:
    profit = deal.profit_percent if deal.profit_percent is not None else -999
    confidence = float(deal.confidence_score)
    speed = 0.0
    if deal.median_time_to_sell_seconds:
        speed = max(0.0, 100.0 - deal.median_time_to_sell_seconds / 3600)
    if strategy == "fast":
        return (speed, confidence, profit)
    if strategy == "profit":
        return (profit, confidence, speed)
    return (confidence, profit, speed)
