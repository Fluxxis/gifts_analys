from __future__ import annotations

import statistics
from datetime import datetime, timedelta, timezone
from typing import Any

from app.config import AnalysisConfig
from app.markets.base import DealAnalysis, GiftListing


def _median(values: list[float]) -> float | None:
    if not values:
        return None
    return float(statistics.median(values))


def _percentile(values: list[float], p: float) -> float | None:
    if not values:
        return None
    values = sorted(values)
    if len(values) == 1:
        return float(values[0])
    idx = (len(values) - 1) * p
    lo = int(idx)
    hi = min(lo + 1, len(values) - 1)
    frac = idx - lo
    return float(values[lo] * (1 - frac) + values[hi] * frac)


def _avg_int(values: list[int]) -> int | None:
    if not values:
        return None
    return int(sum(values) / len(values))


def _median_int(values: list[int]) -> int | None:
    if not values:
        return None
    return int(statistics.median(values))


def _filter_similar_sales(listing: GiftListing, sales: list[dict[str, Any]]) -> list[dict[str, Any]]:
    filtered = []
    for row in sales:
        if str(row.get("collection") or "").lower() != listing.collection.lower():
            continue
        row_model = row.get("model")
        if listing.model and row_model and str(row_model).lower() != listing.model.lower():
            continue
        # symbol/backdrop help when present, but do not drop data if the source lacks those fields.
        row_symbol = row.get("symbol")
        if listing.symbol and row_symbol and str(row_symbol).lower() != listing.symbol.lower():
            continue
        row_backdrop = row.get("backdrop")
        if listing.backdrop and row_backdrop and str(row_backdrop).lower() != listing.backdrop.lower():
            continue
        price = row.get("sold_price_ton")
        if isinstance(price, (int, float)) and price > 0:
            filtered.append(row)
    return filtered


def analyze_listing(
    listing: GiftListing,
    *,
    sales_rows: list[dict[str, Any]],
    floor_rows: list[dict[str, Any]],
    config: AnalysisConfig,
) -> DealAnalysis:
    now = datetime.now(timezone.utc)
    similar = _filter_similar_sales(listing, sales_rows)

    def parse_sold_at(row: dict[str, Any]) -> datetime | None:
        value = row.get("sold_at")
        if not value:
            return None
        try:
            dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc)
        except Exception:
            return None

    sales_24 = [r for r in similar if (parse_sold_at(r) or now) >= now - timedelta(hours=24)]
    sales_7d = [r for r in similar if (parse_sold_at(r) or now) >= now - timedelta(days=7)]
    prices_24 = [float(r["sold_price_ton"]) for r in sales_24 if r.get("sold_price_ton")]
    prices_7d = [float(r["sold_price_ton"]) for r in sales_7d if r.get("sold_price_ton")]

    median_24h = _median(prices_24)
    median_7d = _median(prices_7d)
    quick_sell_price = median_24h * (1 - config.safe_sell_discount_percent / 100) if median_24h else None
    normal_sell_price = median_7d
    greedy_sell_price = _percentile(prices_7d, 0.75)

    floors = [float(r["floor_price_ton"]) for r in floor_rows if r.get("floor_price_ton")]
    model_floor = min(floors) if floors else None

    candidates = []
    if model_floor:
        candidates.append(model_floor)
    if median_24h:
        candidates.append(median_24h * 1.03)
    if median_7d:
        candidates.append(median_7d * 1.05)
    expected_sell_price = min(candidates) if candidates else None

    fees_ton = listing.price_ton * config.market_fee_percent / 100
    net_profit = expected_sell_price - listing.price_ton - fees_ton if expected_sell_price is not None else None
    profit_percent = (net_profit / listing.price_ton * 100) if net_profit is not None and listing.price_ton > 0 else None

    times = [int(r["time_to_sell_seconds"]) for r in sales_7d if r.get("time_to_sell_seconds")]
    avg_time = _avg_int(times)
    median_time = _median_int(times)

    score = 0
    reasons: list[str] = []
    if len(sales_24) >= 5:
        score += 25
        reasons.append("за 24 часа есть 5+ продаж")
    elif len(sales_24) > 0:
        score += 10
        reasons.append("за 24 часа есть продажи, но объём слабый")
    else:
        score -= 30
        reasons.append("нет продаж за 24 часа")

    if len(sales_7d) >= 20:
        score += 15
        reasons.append("за 7 дней есть стабильный объём")
    elif len(sales_7d) >= 3:
        score += 5
        reasons.append("за 7 дней есть немного продаж")
    else:
        score -= 25
        reasons.append("за 7 дней меньше 3 продаж")

    if model_floor and listing.price_ton < model_floor * 0.92:
        score += 20
        reasons.append("цена ниже текущего floor минимум на 8%")
    elif model_floor:
        reasons.append("цена близка к текущему floor")
    else:
        score -= 15
        reasons.append("нет надежного floor для сравнения")

    if median_24h and median_7d:
        diff = abs(median_24h - median_7d) / max(median_7d, 0.000001) * 100
        if diff < 10:
            score += 15
            reasons.append("медиана 24ч и 7д близкие, рынок стабильнее")
        else:
            score -= 5
            reasons.append("медиана 24ч и 7д сильно отличаются")

    markets = {str(r.get("market")) for r in floor_rows if r.get("market")}
    if len(markets) >= 2:
        score += 10
        reasons.append("есть данные с нескольких маркетов")
    else:
        score -= 10
        reasons.append("данные только с одного маркета")

    if median_time is not None and median_time <= 12 * 3600:
        score += 10
        reasons.append("похожие лоты продавались меньше чем за 12 часов")
    elif median_time is None:
        reasons.append("нет данных по времени продажи")
    else:
        score -= 10
        reasons.append("похожие лоты продавались долго")

    if profit_percent is None:
        score -= 20
        reasons.append("нельзя надежно посчитать прибыль")
    elif profit_percent < config.min_profit_percent:
        score -= 20
        reasons.append("прибыль ниже заданного порога")
    else:
        score += 10
        reasons.append("прибыль выше заданного порога")

    score = max(0, min(100, score))

    if score >= 80 and len(sales_24) >= 5 and profit_percent is not None and profit_percent >= 10 and (median_time is not None and median_time <= 8 * 3600):
        risk = "low"
    elif score >= 60 and len(sales_7d) >= 5 and profit_percent is not None and profit_percent >= config.min_profit_percent:
        risk = "medium"
    else:
        risk = "high"

    if risk in {"low", "medium"} and profit_percent is not None and profit_percent >= config.min_profit_percent:
        verdict = "брать"
    elif score >= 45:
        verdict = "наблюдать"
    else:
        verdict = "пропустить"

    return DealAnalysis(
        listing=listing,
        buy_price=listing.price_ton,
        quick_sell_price=quick_sell_price,
        normal_sell_price=normal_sell_price,
        greedy_sell_price=greedy_sell_price,
        expected_sell_price=expected_sell_price,
        fees_ton=fees_ton,
        net_profit_ton=net_profit,
        profit_percent=profit_percent,
        sales_24h=len(sales_24),
        sales_7d=len(sales_7d),
        median_24h=median_24h,
        median_7d=median_7d,
        avg_time_to_sell_seconds=avg_time,
        median_time_to_sell_seconds=median_time,
        confidence_score=score,
        risk_level=risk,
        verdict=verdict,
        reasons=reasons,
    )
