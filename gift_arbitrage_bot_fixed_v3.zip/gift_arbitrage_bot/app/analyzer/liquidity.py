from __future__ import annotations


def liquidity_label(sales_24h: int, sales_7d: int) -> str:
    if sales_24h >= 10:
        return "сильная"
    if sales_24h >= 3 or sales_7d >= 20:
        return "нормальная"
    if sales_7d >= 3:
        return "слабая"
    return "нет данных"
