from __future__ import annotations

ORDER = {"low": 0, "medium": 1, "high": 2}


def risk_allowed(risk: str, max_risk: str) -> bool:
    return ORDER.get(risk, 2) <= ORDER.get(max_risk, 1)
