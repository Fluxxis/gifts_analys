from __future__ import annotations

from typing import Any


def floors_by_market(floor_rows: list[dict[str, Any]]) -> dict[str, float]:
    out: dict[str, float] = {}
    for row in floor_rows:
        market = str(row.get("market") or "unknown")
        price = row.get("floor_price_ton")
        if price is None:
            continue
        value = float(price)
        if market not in out or value < out[market]:
            out[market] = value
    return out
