from __future__ import annotations

from app.utils.time import human_duration


def sell_time_text(median_seconds: int | None) -> str:
    if median_seconds is None:
        return "нет данных по времени продажи"
    return human_duration(median_seconds)
