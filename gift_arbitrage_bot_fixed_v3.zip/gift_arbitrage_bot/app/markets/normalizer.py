from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from app.utils.money import normalize_ton_price, to_float
from app.utils.time import parse_dt


def first_value(raw: dict[str, Any], *paths: str) -> Any:
    for path in paths:
        current: Any = raw
        ok = True
        for part in path.split('.'):
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                ok = False
                break
        if ok and current not in (None, ""):
            return current
    return None


def as_str(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, dict):
        for key in ("name", "title", "slug", "value"):
            if value.get(key):
                return str(value[key])
        return None
    return str(value)


def as_int(value: Any) -> int | None:
    try:
        if value in (None, ""):
            return None
        return int(float(str(value)))
    except Exception:
        return None


def extract_price(raw: dict[str, Any]) -> float | None:
    value = first_value(
        raw,
        "price_ton", "priceTon", "sale_price_ton", "salePriceTon", "amount_ton", "amountTon",
        "price", "sale_price", "salePrice", "amount", "listing.price", "sale.price",
    )
    return normalize_ton_price(value)


def extract_collection(raw: dict[str, Any]) -> str:
    value = first_value(raw, "collection", "collectionName", "collection.name", "gift.collection", "gift.collectionName", "title", "name")
    text = as_str(value)
    return text or "Unknown"


def extract_model(raw: dict[str, Any]) -> str | None:
    value = first_value(raw, "model", "modelName", "model.name", "gift.model", "attributes.model", "traits.model")
    return as_str(value)


def extract_symbol(raw: dict[str, Any]) -> str | None:
    value = first_value(raw, "symbol", "symbolName", "symbol.name", "gift.symbol", "attributes.symbol", "traits.symbol")
    return as_str(value)


def extract_backdrop(raw: dict[str, Any]) -> str | None:
    value = first_value(raw, "backdrop", "backdropName", "backdrop.name", "gift.backdrop", "attributes.backdrop", "traits.backdrop")
    return as_str(value)


def extract_number(raw: dict[str, Any]) -> int | None:
    return as_int(first_value(raw, "number", "gift.number", "nftNumber", "serial"))


def extract_id(raw: dict[str, Any]) -> str:
    value = first_value(raw, "id", "gift_id", "giftId", "gift.id", "nft_id", "nftId", "slug")
    return str(value) if value is not None else "unknown"


def extract_sale_id(raw: dict[str, Any]) -> str | None:
    value = first_value(raw, "sale_id", "saleId", "listing_id", "listingId", "sale.id", "listing.id")
    return str(value) if value is not None else None


def extract_link(raw: dict[str, Any], fallback: str) -> str:
    value = first_value(raw, "link", "url", "shareLink", "share_link", "gift.link")
    if value:
        return str(value)
    slug = first_value(raw, "slug", "gift.slug", "name")
    if slug:
        return f"https://t.me/nft/{slug}"
    return fallback


def extract_seller(raw: dict[str, Any]) -> str | None:
    value = first_value(raw, "seller", "seller.username", "owner", "owner.username", "user.username")
    return as_str(value)


def extract_datetime(raw: dict[str, Any], *paths: str) -> datetime | None:
    for path in paths:
        value = first_value(raw, path)
        dt = parse_dt(str(value)) if value else None
        if dt:
            return dt
        ts = to_float(value)
        if ts:
            try:
                if ts > 10_000_000_000:
                    ts = ts / 1000
                return datetime.fromtimestamp(ts, tz=timezone.utc)
            except Exception:
                pass
    return None
