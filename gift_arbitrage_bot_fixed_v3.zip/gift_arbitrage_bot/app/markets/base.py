from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Protocol


@dataclass(slots=True)
class GiftListing:
    market: str
    gift_id: str
    sale_id: str | None
    collection: str
    model: str | None
    symbol: str | None
    backdrop: str | None
    number: int | None
    price_ton: float
    link: str
    seller: str | None = None
    listed_at: datetime | None = None
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class SaleRecord:
    market: str
    gift_id: str | None
    collection: str
    model: str | None
    symbol: str | None
    backdrop: str | None
    sold_price_ton: float
    listed_at: datetime | None
    sold_at: datetime
    time_to_sell_seconds: int | None
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class FloorRecord:
    market: str
    collection: str
    model: str | None
    symbol: str | None
    backdrop: str | None
    floor_price_ton: float
    checked_at: datetime


@dataclass(slots=True)
class DealAnalysis:
    listing: GiftListing
    buy_price: float
    quick_sell_price: float | None
    normal_sell_price: float | None
    greedy_sell_price: float | None
    expected_sell_price: float | None
    fees_ton: float
    net_profit_ton: float | None
    profit_percent: float | None
    sales_24h: int
    sales_7d: int
    median_24h: float | None
    median_7d: float | None
    avg_time_to_sell_seconds: int | None
    median_time_to_sell_seconds: int | None
    confidence_score: int
    risk_level: str
    verdict: str
    reasons: list[str]


class MarketAdapter(Protocol):
    name: str

    async def status(self) -> dict[str, Any]: ...

    async def search_listings(
        self,
        *,
        min_price: float,
        max_price: float,
        collection: str | None = None,
        model: str | None = None,
        symbol: str | None = None,
        backdrop: str | None = None,
        limit: int = 100,
    ) -> list[GiftListing]: ...

    async def get_sales_history(self, *, collection: str, model: str | None = None, limit: int = 200) -> list[SaleRecord]: ...

    async def get_floor_prices(self, *, collection: str, model: str | None = None) -> list[FloorRecord]: ...

    async def close(self) -> None: ...
