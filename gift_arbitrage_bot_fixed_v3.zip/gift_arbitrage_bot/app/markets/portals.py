from __future__ import annotations

from typing import Any

from app.config import AppConfig
from app.markets.base import FloorRecord, GiftListing, SaleRecord


class PortalsMarket:
    name = "portals"

    def __init__(self, config: AppConfig) -> None:
        self.config = config

    async def close(self) -> None:
        return None

    async def status(self) -> dict[str, Any]:
        cfg = self.config.markets.portals
        if not cfg.enabled:
            return {"market": self.name, "enabled": False, "status": "disabled"}
        if not cfg.auth_data:
            return {"market": self.name, "enabled": True, "status": "not_configured"}
        return {"market": self.name, "enabled": True, "status": "adapter_stub", "note": "Добавь portalsmp/aportalsmp integration под свой auth_data"}

    async def search_listings(self, **kwargs: Any) -> list[GiftListing]:
        return []

    async def get_sales_history(self, **kwargs: Any) -> list[SaleRecord]:
        return []

    async def get_floor_prices(self, **kwargs: Any) -> list[FloorRecord]:
        return []
