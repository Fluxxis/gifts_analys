from __future__ import annotations

from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def build_liquidity_chart(*, deal: dict[str, Any], sales: list[dict[str, Any]], output_path: str | Path) -> str:
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig = plt.figure(figsize=(12.8, 7.2), dpi=100)
    ax = fig.add_subplot(111)
    fig.patch.set_facecolor("#101014")
    ax.set_facecolor("#14141b")
    ax.set_title("Ликвидность продаж", fontsize=16, color="white", pad=14)
    ax.tick_params(axis="x", colors="white")
    ax.tick_params(axis="y", colors="white")
    ax.spines[:].set_color("#666")
    ax.grid(True, alpha=0.25)
    if not sales:
        ax.text(0.5, 0.55, "Нет истории продаж", ha="center", va="center", color="white", fontsize=18, transform=ax.transAxes)
    else:
        buckets: dict[str, int] = {}
        for row in sales:
            key = str(row.get("sold_at", ""))[5:13].replace("T", " ")
            buckets[key] = buckets.get(key, 0) + 1
        xs = list(buckets.keys())
        ys = list(buckets.values())
        ax.bar(xs, ys)
        ax.set_ylabel("Продажи", color="white")
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)
    return str(out)
