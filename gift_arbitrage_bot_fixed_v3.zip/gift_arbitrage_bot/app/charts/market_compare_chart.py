from __future__ import annotations

from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def build_market_compare_chart(*, floors: list[dict[str, Any]], output_path: str | Path) -> str:
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig = plt.figure(figsize=(12.8, 7.2), dpi=100)
    ax = fig.add_subplot(111)
    fig.patch.set_facecolor("#101014")
    ax.set_facecolor("#14141b")
    ax.set_title("Сравнение floor по маркетам", fontsize=16, color="white", pad=14)
    ax.tick_params(axis="x", colors="white")
    ax.tick_params(axis="y", colors="white")
    ax.spines[:].set_color("#666")
    ax.grid(True, alpha=0.25)
    by_market: dict[str, float] = {}
    for row in floors:
        market = str(row.get("market") or "unknown")
        price = row.get("floor_price_ton")
        if price is None:
            continue
        value = float(price)
        if market not in by_market or value < by_market[market]:
            by_market[market] = value
    if not by_market:
        ax.text(0.5, 0.55, "Нет данных по другим маркетам", ha="center", va="center", color="white", fontsize=18, transform=ax.transAxes)
    else:
        ax.bar(list(by_market.keys()), list(by_market.values()))
        ax.set_ylabel("TON", color="white")
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)
    return str(out)
