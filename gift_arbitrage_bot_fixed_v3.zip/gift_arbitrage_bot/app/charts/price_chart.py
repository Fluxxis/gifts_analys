from __future__ import annotations

from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from app.utils.money import fmt_ton


def _label(deal: dict[str, Any]) -> str:
    parts = [str(deal.get("collection") or "Gift")]
    if deal.get("model"):
        parts.append(str(deal.get("model")))
    if deal.get("number"):
        parts.append(f"#{deal.get('number')}")
    return " ".join(parts)


def build_price_chart(*, deal: dict[str, Any], snapshots: list[dict[str, Any]], floors: list[dict[str, Any]], output_path: str | Path) -> str:
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig = plt.figure(figsize=(12.8, 7.2), dpi=100)
    ax = fig.add_subplot(111)
    fig.patch.set_facecolor("#101014")
    ax.set_facecolor("#14141b")
    title = _label(deal)
    ax.set_title(f"График цены: {title}", fontsize=16, color="white", pad=14)
    ax.tick_params(axis="x", colors="white", labelrotation=20)
    ax.tick_params(axis="y", colors="white")
    ax.spines[:].set_color("#666")
    ax.grid(True, alpha=0.25)
    ax.set_ylabel("TON", color="white")

    if snapshots:
        xs = [str(r.get("checked_at", ""))[5:16].replace("T", " ") for r in snapshots]
        ys = [float(r.get("price_ton") or 0) for r in snapshots]
        ax.plot(xs, ys, marker="o", linewidth=2, label="активные цены")
    else:
        ax.text(0.5, 0.62, "Недостаточно истории для точного графика", ha="center", va="center", color="white", fontsize=18, transform=ax.transAxes)
        ax.text(0.5, 0.54, "Показана только текущая найденная цена", ha="center", va="center", color="#cccccc", fontsize=12, transform=ax.transAxes)
        ax.plot(["сейчас"], [float(deal.get("buy_price") or 0)], marker="o", label="текущая цена")

    buy = deal.get("buy_price")
    expected = deal.get("expected_sell_price")
    quick = deal.get("quick_sell_price")
    normal = deal.get("normal_sell_price")
    if buy:
        ax.axhline(float(buy), linestyle="--", linewidth=1.5, label=f"buy {fmt_ton(float(buy))}")
    if expected:
        ax.axhline(float(expected), linestyle="-.", linewidth=1.5, label=f"expected {fmt_ton(float(expected))}")
    if quick:
        ax.axhline(float(quick), linestyle=":", linewidth=1.5, label=f"quick {fmt_ton(float(quick))}")
    if normal:
        ax.axhline(float(normal), linestyle=":", linewidth=1.5, label=f"normal {fmt_ton(float(normal))}")

    # Latest floor by market.
    by_market: dict[str, float] = {}
    for row in floors:
        market = str(row.get("market") or "unknown")
        price = row.get("floor_price_ton")
        if price is None:
            continue
        value = float(price)
        if market not in by_market or value < by_market[market]:
            by_market[market] = value
    for market, value in by_market.items():
        ax.axhline(value, linewidth=1, alpha=0.65, label=f"{market} floor {fmt_ton(value)}")

    ax.legend(loc="best", fontsize=9)
    bottom = (
        f"buy: {fmt_ton(deal.get('buy_price'))} | "
        f"sell: {fmt_ton(deal.get('expected_sell_price'))} | "
        f"profit: {fmt_ton(deal.get('net_profit_ton'))} | "
        f"risk: {deal.get('risk_level')} | confidence: {deal.get('confidence_score')}/100"
    )
    fig.text(0.5, 0.02, bottom, ha="center", color="white", fontsize=11)
    fig.tight_layout(rect=(0.03, 0.06, 0.98, 0.96))
    fig.savefig(out)
    plt.close(fig)
    return str(out)
