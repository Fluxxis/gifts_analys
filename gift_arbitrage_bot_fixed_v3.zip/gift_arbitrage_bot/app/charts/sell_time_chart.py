from __future__ import annotations

from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def build_sell_time_chart(*, deal: dict[str, Any], sales: list[dict[str, Any]], output_path: str | Path) -> str:
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig = plt.figure(figsize=(12.8, 7.2), dpi=100)
    ax = fig.add_subplot(111)
    fig.patch.set_facecolor("#101014")
    ax.set_facecolor("#14141b")
    ax.set_title("Скорость выкупа похожих лотов", fontsize=16, color="white", pad=14)
    ax.tick_params(axis="x", colors="white")
    ax.tick_params(axis="y", colors="white")
    ax.spines[:].set_color("#666")
    ax.grid(True, alpha=0.25)
    hours = [float(r.get("time_to_sell_seconds") or 0) / 3600 for r in sales if r.get("time_to_sell_seconds")]
    if not hours:
        ax.text(0.5, 0.55, "Нет данных по времени продажи", ha="center", va="center", color="white", fontsize=18, transform=ax.transAxes)
    else:
        ax.hist(hours, bins=min(20, max(5, len(hours))))
        ax.set_xlabel("Часы до продажи", color="white")
        ax.set_ylabel("Количество", color="white")
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)
    return str(out)
