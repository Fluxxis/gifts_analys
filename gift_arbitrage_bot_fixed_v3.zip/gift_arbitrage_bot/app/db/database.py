from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import aiosqlite

from app.markets.base import DealAnalysis, FloorRecord, GiftListing, SaleRecord
from app.utils.safe_json import dumps_safe
from app.utils.time import iso_now


class Database:
    def __init__(self, path: str | Path) -> None:
        self.path = str(path)
        self.conn: aiosqlite.Connection | None = None

    async def connect(self) -> None:
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = await aiosqlite.connect(self.path)
        self.conn.row_factory = aiosqlite.Row
        await self.conn.execute("PRAGMA journal_mode=WAL")
        await self.conn.execute("PRAGMA foreign_keys=ON")
        await self._create_tables()

    async def close(self) -> None:
        if self.conn:
            await self.conn.close()
            self.conn = None

    async def _create_tables(self) -> None:
        assert self.conn is not None
        await self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                market TEXT NOT NULL UNIQUE,
                session_name TEXT,
                token TEXT,
                auth_data TEXT,
                token_updated_at TEXT,
                status TEXT NOT NULL DEFAULT 'unknown',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS listings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                market TEXT NOT NULL,
                gift_id TEXT NOT NULL,
                sale_id TEXT,
                collection TEXT NOT NULL,
                model TEXT,
                symbol TEXT,
                backdrop TEXT,
                number INTEGER,
                price_ton REAL NOT NULL,
                link TEXT NOT NULL,
                seller TEXT,
                listed_at TEXT,
                seen_at TEXT NOT NULL,
                raw_json TEXT
            );

            CREATE UNIQUE INDEX IF NOT EXISTS idx_listings_unique_sale
            ON listings(market, gift_id, COALESCE(sale_id, ''));

            CREATE TABLE IF NOT EXISTS snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                market TEXT NOT NULL,
                gift_id TEXT NOT NULL,
                sale_id TEXT,
                collection TEXT NOT NULL,
                model TEXT,
                symbol TEXT,
                backdrop TEXT,
                price_ton REAL NOT NULL,
                checked_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_snapshots_lookup ON snapshots(collection, model, symbol, backdrop, checked_at);

            CREATE TABLE IF NOT EXISTS sales_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                market TEXT NOT NULL,
                gift_id TEXT,
                collection TEXT NOT NULL,
                model TEXT,
                symbol TEXT,
                backdrop TEXT,
                sold_price_ton REAL NOT NULL,
                listed_at TEXT,
                sold_at TEXT NOT NULL,
                time_to_sell_seconds INTEGER,
                raw_json TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_sales_lookup ON sales_history(collection, model, symbol, backdrop, sold_at);

            CREATE TABLE IF NOT EXISTS floor_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                market TEXT NOT NULL,
                collection TEXT NOT NULL,
                model TEXT,
                symbol TEXT,
                backdrop TEXT,
                floor_price_ton REAL NOT NULL,
                checked_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS deals_found (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                market TEXT NOT NULL,
                gift_id TEXT NOT NULL,
                sale_id TEXT,
                collection TEXT NOT NULL,
                model TEXT,
                symbol TEXT,
                backdrop TEXT,
                number INTEGER,
                buy_price REAL NOT NULL,
                expected_sell_price REAL,
                quick_sell_price REAL,
                normal_sell_price REAL,
                greedy_sell_price REAL,
                fees_ton REAL NOT NULL,
                net_profit_ton REAL,
                profit_percent REAL,
                sales_24h INTEGER NOT NULL,
                sales_7d INTEGER NOT NULL,
                avg_time_to_sell_seconds INTEGER,
                median_time_to_sell_seconds INTEGER,
                confidence_score INTEGER NOT NULL,
                risk_level TEXT NOT NULL,
                verdict TEXT NOT NULL,
                reasons_json TEXT NOT NULL,
                link TEXT NOT NULL,
                chart_path TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS watchlist (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                min_price REAL NOT NULL,
                max_price REAL NOT NULL,
                market TEXT NOT NULL,
                collection TEXT,
                model TEXT,
                symbol TEXT,
                backdrop TEXT,
                min_profit_percent REAL NOT NULL,
                max_risk TEXT NOT NULL,
                strategy TEXT NOT NULL,
                enabled INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS sent_alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                sale_key TEXT NOT NULL,
                created_at TEXT NOT NULL,
                UNIQUE(user_id, sale_key) ON CONFLICT IGNORE
            );

            CREATE TABLE IF NOT EXISTS chart_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                deal_id INTEGER NOT NULL,
                chart_type TEXT NOT NULL,
                path TEXT NOT NULL,
                created_at TEXT NOT NULL,
                UNIQUE(deal_id, chart_type) ON CONFLICT REPLACE
            );

            CREATE TABLE IF NOT EXISTS errors (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            """
        )
        await self.conn.commit()

    async def execute(self, query: str, params: tuple[Any, ...] = ()) -> None:
        assert self.conn is not None
        await self.conn.execute(query, params)
        await self.conn.commit()

    async def fetchone(self, query: str, params: tuple[Any, ...] = ()) -> dict[str, Any] | None:
        assert self.conn is not None
        cur = await self.conn.execute(query, params)
        row = await cur.fetchone()
        return dict(row) if row else None

    async def fetchall(self, query: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
        assert self.conn is not None
        cur = await self.conn.execute(query, params)
        rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def save_listing(self, listing: GiftListing) -> None:
        assert self.conn is not None
        await self.conn.execute(
            """
            INSERT OR REPLACE INTO listings(market, gift_id, sale_id, collection, model, symbol, backdrop, number, price_ton, link, seller, listed_at, seen_at, raw_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                listing.market, listing.gift_id, listing.sale_id, listing.collection, listing.model, listing.symbol,
                listing.backdrop, listing.number, listing.price_ton, listing.link, listing.seller,
                listing.listed_at.isoformat() if listing.listed_at else None, iso_now(), dumps_safe(listing.raw),
            ),
        )

    async def save_snapshot(self, listing: GiftListing) -> None:
        assert self.conn is not None
        await self.conn.execute(
            """
            INSERT INTO snapshots(market, gift_id, sale_id, collection, model, symbol, backdrop, price_ton, checked_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (listing.market, listing.gift_id, listing.sale_id, listing.collection, listing.model, listing.symbol, listing.backdrop, listing.price_ton, iso_now()),
        )

    async def save_listings(self, listings: list[GiftListing]) -> None:
        for listing in listings:
            await self.save_listing(listing)
            await self.save_snapshot(listing)
        assert self.conn is not None
        await self.conn.commit()

    async def save_sale_records(self, records: list[SaleRecord]) -> None:
        assert self.conn is not None
        for record in records:
            await self.conn.execute(
                """
                INSERT INTO sales_history(market, gift_id, collection, model, symbol, backdrop, sold_price_ton, listed_at, sold_at, time_to_sell_seconds, raw_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    record.market, record.gift_id, record.collection, record.model, record.symbol, record.backdrop,
                    record.sold_price_ton,
                    record.listed_at.isoformat() if record.listed_at else None,
                    record.sold_at.isoformat(), record.time_to_sell_seconds, dumps_safe(record.raw),
                ),
            )
        await self.conn.commit()

    async def save_floor_records(self, records: list[FloorRecord]) -> None:
        assert self.conn is not None
        for record in records:
            await self.conn.execute(
                """
                INSERT INTO floor_history(market, collection, model, symbol, backdrop, floor_price_ton, checked_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (record.market, record.collection, record.model, record.symbol, record.backdrop, record.floor_price_ton, record.checked_at.isoformat()),
            )
        await self.conn.commit()

    async def get_recent_sales(self, collection: str, model: str | None, hours: int = 168) -> list[dict[str, Any]]:
        query = """
            SELECT * FROM sales_history
            WHERE lower(collection) = lower(?)
              AND (? IS NULL OR lower(COALESCE(model, '')) = lower(?))
              AND sold_at >= datetime('now', ?)
            ORDER BY sold_at DESC
        """
        return await self.fetchall(query, (collection, model, model, f"-{hours} hours"))

    async def get_recent_snapshots(self, collection: str, model: str | None, hours: int = 168) -> list[dict[str, Any]]:
        query = """
            SELECT * FROM snapshots
            WHERE lower(collection) = lower(?)
              AND (? IS NULL OR lower(COALESCE(model, '')) = lower(?))
              AND checked_at >= datetime('now', ?)
            ORDER BY checked_at ASC
        """
        return await self.fetchall(query, (collection, model, model, f"-{hours} hours"))

    async def get_latest_floors(self, collection: str, model: str | None) -> list[dict[str, Any]]:
        query = """
            SELECT * FROM floor_history
            WHERE lower(collection) = lower(?)
              AND (? IS NULL OR lower(COALESCE(model, '')) = lower(?))
            ORDER BY checked_at DESC
            LIMIT 20
        """
        return await self.fetchall(query, (collection, model, model))

    async def save_deal(self, user_id: int, deal: DealAnalysis) -> int:
        assert self.conn is not None
        cur = await self.conn.execute(
            """
            INSERT INTO deals_found(user_id, market, gift_id, sale_id, collection, model, symbol, backdrop, number, buy_price,
            expected_sell_price, quick_sell_price, normal_sell_price, greedy_sell_price, fees_ton, net_profit_ton, profit_percent,
            sales_24h, sales_7d, avg_time_to_sell_seconds, median_time_to_sell_seconds, confidence_score, risk_level, verdict,
            reasons_json, link, chart_path, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                user_id, deal.listing.market, deal.listing.gift_id, deal.listing.sale_id, deal.listing.collection,
                deal.listing.model, deal.listing.symbol, deal.listing.backdrop, deal.listing.number, deal.buy_price,
                deal.expected_sell_price, deal.quick_sell_price, deal.normal_sell_price, deal.greedy_sell_price,
                deal.fees_ton, deal.net_profit_ton, deal.profit_percent, deal.sales_24h, deal.sales_7d,
                deal.avg_time_to_sell_seconds, deal.median_time_to_sell_seconds, deal.confidence_score,
                deal.risk_level, deal.verdict, json.dumps(deal.reasons, ensure_ascii=False), deal.listing.link, None, iso_now(),
            ),
        )
        await self.conn.commit()
        return int(cur.lastrowid)

    async def get_deal(self, deal_id: int) -> dict[str, Any] | None:
        row = await self.fetchone("SELECT * FROM deals_found WHERE id = ?", (deal_id,))
        if row:
            try:
                row["reasons"] = json.loads(row.get("reasons_json") or "[]")
            except Exception:
                row["reasons"] = []
        return row

    async def cache_chart(self, deal_id: int, chart_type: str, path: str) -> None:
        assert self.conn is not None
        await self.conn.execute(
            "INSERT OR REPLACE INTO chart_cache(deal_id, chart_type, path, created_at) VALUES (?, ?, ?, ?)",
            (deal_id, chart_type, path, iso_now()),
        )
        await self.conn.execute("UPDATE deals_found SET chart_path = ? WHERE id = ?", (path, deal_id))
        await self.conn.commit()

    async def add_watchlist(self, data: dict[str, Any]) -> int:
        assert self.conn is not None
        cur = await self.conn.execute(
            """
            INSERT INTO watchlist(user_id, min_price, max_price, market, collection, model, symbol, backdrop, min_profit_percent, max_risk, strategy, enabled, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
            """,
            (
                data["user_id"], data["min_price"], data["max_price"], data.get("market") or "all",
                data.get("collection"), data.get("model"), data.get("symbol"), data.get("backdrop"),
                data.get("min_profit_percent", 8.0), data.get("max_risk", "medium"), data.get("strategy", "balance"), iso_now(),
            ),
        )
        await self.conn.commit()
        return int(cur.lastrowid)

    async def list_watchlist(self, user_id: int | None = None, enabled_only: bool = True) -> list[dict[str, Any]]:
        where = []
        params: list[Any] = []
        if user_id is not None:
            where.append("user_id = ?")
            params.append(user_id)
        if enabled_only:
            where.append("enabled = 1")
        query = "SELECT * FROM watchlist"
        if where:
            query += " WHERE " + " AND ".join(where)
        query += " ORDER BY created_at DESC"
        return await self.fetchall(query, tuple(params))

    async def mark_alert_sent(self, user_id: int, sale_key: str) -> bool:
        assert self.conn is not None
        cur = await self.conn.execute(
            "INSERT OR IGNORE INTO sent_alerts(user_id, sale_key, created_at) VALUES (?, ?, ?)",
            (user_id, sale_key, iso_now()),
        )
        await self.conn.commit()
        return cur.rowcount > 0

    async def log_error(self, source: str, message: str) -> None:
        await self.execute("INSERT INTO errors(source, message, created_at) VALUES (?, ?, ?)", (source, message[:2000], iso_now()))

    async def stats(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for name in ("listings", "snapshots", "sales_history", "deals_found", "watchlist", "errors"):
            row = await self.fetchone(f"SELECT COUNT(*) AS total FROM {name}")
            out[name] = int(row["total"] if row else 0)
        last_scan = await self.fetchone("SELECT MAX(checked_at) AS last FROM snapshots")
        out["last_scan"] = last_scan.get("last") if last_scan else None
        return out
