#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

python3 -m venv venv
./venv/bin/python -m pip install --upgrade pip setuptools wheel
./venv/bin/pip install -r requirements.txt

mkdir -p data/sessions data/charts data/logs

if [ ! -f config.json ]; then
  cp config.example.json config.json
  echo "Создан config.json. Заполни bot_token, admin_ids, api_id и api_hash."
fi

echo "Установка готова. Дальше: nano config.json && ./start.sh"
