from aiogram.fsm.state import State, StatesGroup


class ScanStates(StatesGroup):
    waiting_min_price = State()
    waiting_max_price = State()
    waiting_market = State()
    waiting_strategy = State()
    waiting_risk = State()


class WatchlistStates(StatesGroup):
    waiting_min_price = State()
    waiting_max_price = State()
    waiting_market = State()
    waiting_strategy = State()
    waiting_risk = State()
