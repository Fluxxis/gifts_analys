from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal


@dataclass(slots=True)
class TelegramUserConfig:
    api_id: int = 0
    api_hash: str = ""
    session_name: str = "./data/sessions/market_user"


@dataclass(slots=True)
class ScanConfig:
    default_interval_seconds: int = 60
    max_pages_per_scan: int = 10
    items_per_page: int = 50
    request_timeout_seconds: int = 30
    retry_count: int = 3


@dataclass(slots=True)
class MrktConfig:
    enabled: bool = True
    base_url: str = "https://api.tgmrkt.io/api/v1"
    referer: str = "https://cdn.tgmrkt.io/"
    bot_username: str = "mrkt"
    app_short_name: str = "app"
    platform: str = "android"
    token: str = ""


@dataclass(slots=True)
class ExternalMarketConfig:
    enabled: bool = False
    auth_data: str = ""
    base_url: str = ""


@dataclass(slots=True)
class MarketsConfig:
    mrkt: MrktConfig = field(default_factory=MrktConfig)
    tonnel: ExternalMarketConfig = field(default_factory=ExternalMarketConfig)
    portals: ExternalMarketConfig = field(default_factory=ExternalMarketConfig)


@dataclass(slots=True)
class AnalysisConfig:
    min_profit_percent: float = 8.0
    min_sales_24h: int = 3
    min_confidence_score: int = 60
    market_fee_percent: float = 5.0
    safe_sell_discount_percent: float = 2.0
    max_allowed_risk: Literal["low", "medium", "high"] = "medium"


@dataclass(slots=True)
class UiConfig:
    results_per_page: int = 5
    charts_dir: str = "./data/charts"
    ton_decimals: int = 3


@dataclass(slots=True)
class AppConfig:
    bot_token: str
    admin_ids: list[int] = field(default_factory=list)
    database_path: str = "./data/gifts.db"
    telegram_user: TelegramUserConfig = field(default_factory=TelegramUserConfig)
    scan: ScanConfig = field(default_factory=ScanConfig)
    markets: MarketsConfig = field(default_factory=MarketsConfig)
    analysis: AnalysisConfig = field(default_factory=AnalysisConfig)
    ui: UiConfig = field(default_factory=UiConfig)

    @property
    def db_path(self) -> Path:
        return Path(self.database_path).expanduser().resolve()

    @property
    def charts_path(self) -> Path:
        return Path(self.ui.charts_dir).expanduser().resolve()


def _dataclass_from_dict(cls: type, raw: dict[str, Any]):
    if cls is TelegramUserConfig:
        return TelegramUserConfig(**raw)
    if cls is ScanConfig:
        return ScanConfig(**raw)
    if cls is MrktConfig:
        return MrktConfig(**raw)
    if cls is ExternalMarketConfig:
        return ExternalMarketConfig(**raw)
    if cls is AnalysisConfig:
        return AnalysisConfig(**raw)
    if cls is UiConfig:
        return UiConfig(**raw)
    raise TypeError(cls)


def load_config(path: str | Path = "config.json") -> AppConfig:
    config_path = Path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"config.json не найден: {config_path.resolve()}")
    raw = json.loads(config_path.read_text("utf-8"))
    markets_raw = raw.get("markets", {}) or {}
    markets = MarketsConfig(
        mrkt=_dataclass_from_dict(MrktConfig, markets_raw.get("mrkt", {}) or {}),
        tonnel=_dataclass_from_dict(ExternalMarketConfig, markets_raw.get("tonnel", {}) or {}),
        portals=_dataclass_from_dict(ExternalMarketConfig, markets_raw.get("portals", {}) or {}),
    )
    return AppConfig(
        bot_token=str(raw.get("bot_token") or ""),
        admin_ids=[int(x) for x in raw.get("admin_ids", [])],
        database_path=str(raw.get("database_path") or "./data/gifts.db"),
        telegram_user=_dataclass_from_dict(TelegramUserConfig, raw.get("telegram_user", {}) or {}),
        scan=_dataclass_from_dict(ScanConfig, raw.get("scan", {}) or {}),
        markets=markets,
        analysis=_dataclass_from_dict(AnalysisConfig, raw.get("analysis", {}) or {}),
        ui=_dataclass_from_dict(UiConfig, raw.get("ui", {}) or {}),
    )
