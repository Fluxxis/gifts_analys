from __future__ import annotations


def parse_price(text: str) -> float:
    value = text.replace(",", ".").strip()
    price = float(value)
    if price < 0:
        raise ValueError("Цена не должна быть меньше 0")
    if price > 1_000_000:
        raise ValueError("Слишком большая цена")
    return price


def normalize_market(value: str) -> str:
    value = value.lower().strip()
    if value in {"all", "все", "all_markets"}:
        return "all"
    if value in {"mrkt", "tonnel", "portals"}:
        return value
    return "all"


def normalize_risk(value: str) -> str:
    value = value.lower().strip()
    if value in {"low", "medium", "high"}:
        return value
    return "medium"
