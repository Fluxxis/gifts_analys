from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.bot.keyboards import deal_keyboard, market_keyboard, risk_keyboard, strategy_keyboard
from app.bot.texts import deal_card_text, scan_summary
from app.states import ScanStates
from app.tasks.scanner import ScanEngine
from app.utils.validators import parse_price

router = Router()


@router.callback_query(F.data == "scan:custom")
async def custom_price(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await state.set_state(ScanStates.waiting_min_price)
    await callback.message.edit_text("Введи цену от. Пример: 10")
    await callback.answer()


@router.callback_query(F.data.startswith("scan:preset:"))
async def preset_price(callback: CallbackQuery, state: FSMContext) -> None:
    parts = str(callback.data).split(":")
    min_price = float(parts[2])
    max_price = float(parts[3])
    await state.update_data(min_price=min_price, max_price=max_price)
    await state.set_state(ScanStates.waiting_market)
    await callback.message.edit_text(f"Диапазон: {min_price:g}-{max_price:g} TON. Выбери маркет.", reply_markup=market_keyboard("scan"))
    await callback.answer()


@router.message(ScanStates.waiting_min_price)
async def input_min_price(message: Message, state: FSMContext) -> None:
    try:
        price = parse_price(message.text or "")
    except Exception:
        await message.answer("Введи число. Пример: 10")
        return
    await state.update_data(min_price=price)
    await state.set_state(ScanStates.waiting_max_price)
    await message.answer("Введи цену до. Пример: 15")


@router.message(ScanStates.waiting_max_price)
async def input_max_price(message: Message, state: FSMContext) -> None:
    try:
        max_price = parse_price(message.text or "")
    except Exception:
        await message.answer("Введи число. Пример: 15")
        return
    data = await state.get_data()
    min_price = float(data.get("min_price") or 0)
    if max_price <= min_price:
        await message.answer("Цена до должна быть больше цены от.")
        return
    await state.update_data(max_price=max_price)
    await state.set_state(ScanStates.waiting_market)
    await message.answer(f"Диапазон: {min_price:g}-{max_price:g} TON. Выбери маркет.", reply_markup=market_keyboard("scan"))


@router.callback_query(ScanStates.waiting_market, F.data.startswith("scan:market:"))
async def choose_market(callback: CallbackQuery, state: FSMContext) -> None:
    market = str(callback.data).split(":")[-1]
    await state.update_data(market=market)
    await state.set_state(ScanStates.waiting_strategy)
    await callback.message.edit_text("Выбери стратегию сортировки.", reply_markup=strategy_keyboard("scan"))
    await callback.answer()


@router.callback_query(ScanStates.waiting_strategy, F.data.startswith("scan:strategy:"))
async def choose_strategy(callback: CallbackQuery, state: FSMContext) -> None:
    strategy = str(callback.data).split(":")[-1]
    await state.update_data(strategy=strategy)
    await state.set_state(ScanStates.waiting_risk)
    await callback.message.edit_text("Выбери максимальный риск.", reply_markup=risk_keyboard("scan"))
    await callback.answer()


@router.callback_query(ScanStates.waiting_risk, F.data.startswith("scan:risk:"))
async def choose_risk(callback: CallbackQuery, state: FSMContext, scanner: ScanEngine) -> None:
    max_risk = str(callback.data).split(":")[-1]
    await state.update_data(max_risk=max_risk)
    data = await state.get_data()
    await state.clear()
    min_price = float(data["min_price"])
    max_price = float(data["max_price"])
    market = str(data.get("market") or "all")
    strategy = str(data.get("strategy") or "balance")
    await callback.message.edit_text(
        f"Анализирую рынок. Диапазон {min_price:g}-{max_price:g} TON, маркет: {market}, риск: {max_risk}."
    )
    await callback.answer()
    results = await scanner.scan(
        user_id=callback.from_user.id,
        min_price=min_price,
        max_price=max_price,
        market=market,
        strategy=strategy,
        max_risk=max_risk,
        save_deals=True,
    )
    await callback.message.answer(scan_summary(len(results)))
    for deal_id, deal in results:
        await callback.message.answer(deal_card_text(deal_id, deal), reply_markup=deal_keyboard(deal_id, deal.listing.link))
