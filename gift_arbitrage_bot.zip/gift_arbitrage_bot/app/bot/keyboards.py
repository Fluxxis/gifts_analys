from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder


def main_menu(is_admin: bool = False) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="🔎 Найти выгодные гифты", callback_data="scan:start")
    kb.button(text="⚡ 10-15 TON", callback_data="scan:preset:10:15")
    kb.button(text="📊 Мои фильтры", callback_data="watch:list")
    kb.button(text="👀 Watchlist", callback_data="watch:create")
    kb.button(text="📈 Последние сделки", callback_data="deals:last")
    if is_admin:
        kb.button(text="🛠 Админка", callback_data="admin:status")
    kb.adjust(1, 2, 2, 1)
    return kb.as_markup()


def price_presets() -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    for a, b in [(1, 5), (5, 10), (10, 15), (15, 25), (25, 50)]:
        kb.button(text=f"{a}-{b} TON", callback_data=f"scan:preset:{a}:{b}")
    kb.button(text="Своя цена", callback_data="scan:custom")
    kb.button(text="⬅ Назад", callback_data="menu:main")
    kb.adjust(2, 2, 1, 1)
    return kb.as_markup()


def market_keyboard(prefix: str = "scan") -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="MRKT", callback_data=f"{prefix}:market:mrkt")
    kb.button(text="Tonnel", callback_data=f"{prefix}:market:tonnel")
    kb.button(text="Portals", callback_data=f"{prefix}:market:portals")
    kb.button(text="Все", callback_data=f"{prefix}:market:all")
    kb.adjust(2, 2)
    return kb.as_markup()


def strategy_keyboard(prefix: str = "scan") -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="Быстрая продажа", callback_data=f"{prefix}:strategy:fast")
    kb.button(text="Баланс", callback_data=f"{prefix}:strategy:balance")
    kb.button(text="Макс прибыль", callback_data=f"{prefix}:strategy:profit")
    kb.adjust(1)
    return kb.as_markup()


def risk_keyboard(prefix: str = "scan") -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="Низкий", callback_data=f"{prefix}:risk:low")
    kb.button(text="Средний", callback_data=f"{prefix}:risk:medium")
    kb.button(text="Любой", callback_data=f"{prefix}:risk:high")
    kb.adjust(3)
    return kb.as_markup()


def deal_keyboard(deal_id: int | None, link: str) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    if deal_id is not None:
        kb.button(text="📈 График", callback_data=f"deal:chart:{deal_id}")
        kb.button(text="📋 Подробнее", callback_data=f"deal:details:{deal_id}")
    kb.add(InlineKeyboardButton(text="🛒 Открыть лот", url=link))
    if deal_id is not None:
        kb.button(text="⭐ Watchlist", callback_data=f"deal:watch:{deal_id}")
        kb.button(text="❌ Скрыть", callback_data="deal:hide")
    kb.adjust(2, 1, 2)
    return kb.as_markup()


def chart_keyboard(deal_id: int, link: str) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="⬅ Назад к карточке", callback_data=f"deal:details:{deal_id}")
    kb.add(InlineKeyboardButton(text="🛒 Открыть лот", url=link))
    kb.button(text="🔄 Обновить анализ", callback_data=f"deal:refresh:{deal_id}")
    kb.button(text="⭐ Watchlist", callback_data=f"deal:watch:{deal_id}")
    kb.adjust(1, 1, 2)
    return kb.as_markup()


def admin_keyboard() -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="🔄 Обновить", callback_data="admin:status")
    kb.button(text="📋 Ошибки", callback_data="admin:errors")
    kb.button(text="⬅ Назад", callback_data="menu:main")
    kb.adjust(2, 1)
    return kb.as_markup()
