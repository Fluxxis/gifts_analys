from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.bot.keyboards import market_keyboard, risk_keyboard, strategy_keyboard
from app.db import Database
from app.states import WatchlistStates
from app.utils.validators import parse_price

router = Router()


@router.callback_query(F.data == "watch:create")
async def watch_create(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await state.set_state(WatchlistStates.waiting_min_price)
    await callback.message.edit_text("Watchlist. Введи цену от. Пример: 10")
    await callback.answer()


@router.message(WatchlistStates.waiting_min_price)
async def watch_min(message: Message, state: FSMContext) -> None:
    try:
        price = parse_price(message.text or "")
    except Exception:
        await message.answer("Введи число. Пример: 10")
        return
    await state.update_data(min_price=price)
    await state.set_state(WatchlistStates.waiting_max_price)
    await message.answer("Введи цену до. Пример: 15")


@router.message(WatchlistStates.waiting_max_price)
async def watch_max(message: Message, state: FSMContext) -> None:
    try:
        price = parse_price(message.text or "")
    except Exception:
        await message.answer("Введи число. Пример: 15")
        return
    data = await state.get_data()
    if price <= float(data.get("min_price") or 0):
        await message.answer("Цена до должна быть больше цены от.")
        return
    await state.update_data(max_price=price)
    await state.set_state(WatchlistStates.waiting_market)
    await message.answer("Выбери маркет.", reply_markup=market_keyboard("watch"))


@router.callback_query(WatchlistStates.waiting_market, F.data.startswith("watch:market:"))
async def watch_market(callback: CallbackQuery, state: FSMContext) -> None:
    await state.update_data(market=str(callback.data).split(":")[-1])
    await state.set_state(WatchlistStates.waiting_strategy)
    await callback.message.edit_text("Выбери стратегию.", reply_markup=strategy_keyboard("watch"))
    await callback.answer()


@router.callback_query(WatchlistStates.waiting_strategy, F.data.startswith("watch:strategy:"))
async def watch_strategy(callback: CallbackQuery, state: FSMContext) -> None:
    await state.update_data(strategy=str(callback.data).split(":")[-1])
    await state.set_state(WatchlistStates.waiting_risk)
    await callback.message.edit_text("Выбери максимальный риск.", reply_markup=risk_keyboard("watch"))
    await callback.answer()


@router.callback_query(WatchlistStates.waiting_risk, F.data.startswith("watch:risk:"))
async def watch_risk(callback: CallbackQuery, state: FSMContext, db: Database) -> None:
    await state.update_data(max_risk=str(callback.data).split(":")[-1])
    data = await state.get_data()
    await state.clear()
    await db.add_watchlist(
        {
            "user_id": callback.from_user.id,
            "min_price": float(data["min_price"]),
            "max_price": float(data["max_price"]),
            "market": data.get("market") or "all",
            "min_profit_percent": 8.0,
            "max_risk": data.get("max_risk") or "medium",
            "strategy": data.get("strategy") or "balance",
        }
    )
    await callback.message.edit_text("Watchlist создан. Бот будет проверять рынок по расписанию.")
    await callback.answer()


@router.callback_query(F.data == "watch:list")
async def watch_list(callback: CallbackQuery, db: Database) -> None:
    rows = await db.list_watchlist(callback.from_user.id)
    if not rows:
        await callback.message.edit_text("Watchlist пуст. Создай правило через кнопку Watchlist.")
    else:
        text = "📊 Твои фильтры\n\n" + "\n".join(
            f"#{r['id']} | {r['min_price']}-{r['max_price']} TON | {r['market']} | риск {r['max_risk']} | {r['strategy']}"
            for r in rows[:20]
        )
        await callback.message.edit_text(text)
    await callback.answer()
