from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message

from app.bot.keyboards import main_menu, price_presets
from app.bot.texts import start_text
from app.config import AppConfig

router = Router()


@router.message(Command("start"))
async def cmd_start(message: Message, config: AppConfig) -> None:
    is_admin = message.from_user is not None and message.from_user.id in config.admin_ids
    await message.answer(start_text(), reply_markup=main_menu(is_admin))


@router.callback_query(F.data == "menu:main")
async def cb_main(callback: CallbackQuery, config: AppConfig) -> None:
    is_admin = callback.from_user.id in config.admin_ids
    await callback.message.edit_text(start_text(), reply_markup=main_menu(is_admin))
    await callback.answer()


@router.callback_query(F.data == "scan:start")
async def cb_scan_start(callback: CallbackQuery) -> None:
    await callback.message.edit_text("Выбери диапазон цены или укажи свой.", reply_markup=price_presets())
    await callback.answer()
