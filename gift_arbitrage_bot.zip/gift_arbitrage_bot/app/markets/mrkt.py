from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

import aiohttp

from app.auth.mrkt_auth import MrktAuthError, get_mrkt_token
from app.config import AppConfig
from app.markets.base import FloorRecord, GiftListing, SaleRecord
from app.markets.normalizer import (
    extract_backdrop,
    extract_collection,
    extract_datetime,
    extract_id,
    extract_link,
    extract_model,
    extract_number,
    extract_price,
    extract_sale_id,
    extract_seller,
    extract_symbol,
    first_value,
)
from app.utils.money import normalize_ton_price
from app.utils.time import now_utc

logger = logging.getLogger(__name__)


class MrktMarket:
    name = "mrkt"

    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self._session: aiohttp.ClientSession | None = None
        self._token: str | None = config.markets.mrkt.token or None
        self._status = "not_started"

    async def start(self) -> None:
        if self._session is None:
            timeout = aiohttp.ClientTimeout(total=self.config.scan.request_timeout_seconds)
            self._session = aiohttp.ClientSession(timeout=timeout)
        await self.ensure_token()

    async def close(self) -> None:
        if self._session is not None:
            await self._session.close()
            self._session = None

    async def status(self) -> dict[str, Any]:
        return {"market": self.name, "enabled": self.config.markets.mrkt.enabled, "status": self._status, "has_token": bool(self._token)}

    async def ensure_token(self, force: bool = False) -> str:
        if self._token and not force:
            self._status = "ok"
            return self._token
        try:
            self._token = await get_mrkt_token(self.config)
            self._status = "ok"
            return self._token
        except MrktAuthError:
            self._status = "auth_error"
            raise
        except Exception:
            self._status = "auth_error"
            raise

    def _headers(self) -> dict[str, str]:
        if not self._token:
            raise RuntimeError("MRKT token отсутствует")
        return {"Authorization": self._token, "Referer": self.config.markets.mrkt.referer}

    async def _post_json(self, path: str, payload: dict[str, Any], *, retry_auth: bool = True) -> Any:
        if self._session is None:
            await self.start()
        assert self._session is not None
        url = f"{self.config.markets.mrkt.base_url.rstrip('/')}/{path.lstrip('/')}"
        async with self._session.post(url, headers=self._headers(), json=payload) as response:
            if response.status == 401 and retry_auth:
                await self.ensure_token(force=True)
                return await self._post_json(path, payload, retry_auth=False)
            try:
                data = await response.json(content_type=None)
            except Exception:
                text = await response.text()
                raise RuntimeError(f"MRKT {path} вернул не JSON. HTTP {response.status}. Ответ: {text[:500]}")
            if response.status >= 400:
                raise RuntimeError(f"MRKT {path} ошибка HTTP {response.status}. Ответ: {data}")
            return data

    async def _get_json(self, path: str, *, retry_auth: bool = True) -> Any:
        if self._session is None:
            await self.start()
        assert self._session is not None
        url = f"{self.config.markets.mrkt.base_url.rstrip('/')}/{path.lstrip('/')}"
        async with self._session.get(url, headers=self._headers()) as response:
            if response.status == 401 and retry_auth:
                await self.ensure_token(force=True)
                return await self._get_json(path, retry_auth=False)
            try:
                data = await response.json(content_type=None)
            except Exception:
                text = await response.text()
                raise RuntimeError(f"MRKT {path} вернул не JSON. HTTP {response.status}. Ответ: {text[:500]}")
            if response.status >= 400:
                raise RuntimeError(f"MRKT {path} ошибка HTTP {response.status}. Ответ: {data}")
            return data

    def _items_from_response(self, data: Any) -> tuple[list[dict[str, Any]], str | None]:
        if isinstance(data, list):
            return [x for x in data if isinstance(x, dict)], None
        if not isinstance(data, dict):
            return [], None
        for key in ("gifts", "items", "results", "data"):
            value = data.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)], data.get("cursor") or data.get("nextCursor") or data.get("next_cursor")
            if isinstance(value, dict):
                for sub in ("gifts", "items", "results"):
                    sub_value = value.get(sub)
                    if isinstance(sub_value, list):
                        return [x for x in sub_value if isinstance(x, dict)], value.get("cursor") or value.get("nextCursor") or data.get("cursor")
        return [], data.get("cursor") or data.get("nextCursor")

    def _normalize_listing(self, raw: dict[str, Any]) -> GiftListing | None:
        price = extract_price(raw)
        if price is None:
            return None
        fallback_link = "https://t.me/mrkt/app"
        return GiftListing(
            market=self.name,
            gift_id=extract_id(raw),
            sale_id=extract_sale_id(raw),
            collection=extract_collection(raw),
            model=extract_model(raw),
            symbol=extract_symbol(raw),
            backdrop=extract_backdrop(raw),
            number=extract_number(raw),
            price_ton=price,
            link=extract_link(raw, fallback_link),
            seller=extract_seller(raw),
            listed_at=extract_datetime(raw, "listed_at", "listedAt", "created_at", "createdAt", "sale.createdAt", "listing.createdAt"),
            raw=raw,
        )

    async def search_listings(
        self,
        *,
        min_price: float,
        max_price: float,
        collection: str | None = None,
        model: str | None = None,
        symbol: str | None = None,
        backdrop: str | None = None,
        limit: int = 100,
    ) -> list[GiftListing]:
        if not self.config.markets.mrkt.enabled:
            return []
        await self.start()
        listings: list[GiftListing] = []
        cursor = ""
        pages = max(1, self.config.scan.max_pages_per_scan)
        per_page = min(max(1, self.config.scan.items_per_page), 100)
        for _ in range(pages):
            def make_payload(price_unit: str) -> dict[str, Any]:
                if price_unit == "nano":
                    min_value = int(min_price * 1_000_000_000)
                    max_value = int(max_price * 1_000_000_000)
                else:
                    min_value = min_price
                    max_value = max_price
                return {
                    "collectionNames": [collection] if collection else [],
                    "modelNames": [model] if model else [],
                    "backdropNames": [backdrop] if backdrop else [],
                    "symbolNames": [symbol] if symbol else [],
                    "ordering": "Price",
                    "lowToHigh": True,
                    "maxPrice": max_value,
                    "minPrice": min_value,
                    "mintable": None,
                    "number": None,
                    "count": per_page,
                    "cursor": cursor,
                    "query": None,
                    "promotedFirst": False,
                }

            data = await self._post_json("/gifts/saling", make_payload("ton"))
            items, next_cursor = self._items_from_response(data)
            if not items and not listings and cursor == "":
                # Different MRKT wrappers have used TON and nanoTON for minPrice/maxPrice.
                # Try nanoTON only when the normal TON request returns no rows.
                data = await self._post_json("/gifts/saling", make_payload("nano"))
                items, next_cursor = self._items_from_response(data)
            for raw in items:
                listing = self._normalize_listing(raw)
                if listing:
                    listings.append(listing)
                    if len(listings) >= limit:
                        return listings
            if not next_cursor or next_cursor == cursor:
                break
            cursor = str(next_cursor)
        return listings

    async def get_sales_history(self, *, collection: str, model: str | None = None, limit: int = 200) -> list[SaleRecord]:
        # MRKT endpoints for exact sales history are not guaranteed. Try known feed-like endpoints.
        await self.start()
        records: list[SaleRecord] = []
        paths = ("/feed", "/activities/feed", "/gifts/feed")
        for path in paths:
            try:
                data = await self._get_json(path)
            except Exception as exc:
                logger.debug("MRKT feed endpoint failed %s: %s", path, exc)
                continue
            items, _ = self._items_from_response(data)
            for raw in items:
                event_type = str(first_value(raw, "type", "event", "action") or "").lower()
                if event_type and not any(x in event_type for x in ("sale", "sold", "buy", "purchase")):
                    continue
                gift_raw = first_value(raw, "gift")
                merged = dict(gift_raw) if isinstance(gift_raw, dict) else dict(raw)
                merged.update({k: v for k, v in raw.items() if k not in merged})
                if extract_collection(merged).lower() != collection.lower():
                    continue
                if model and (extract_model(merged) or "").lower() != model.lower():
                    continue
                price = normalize_ton_price(first_value(raw, "amount", "amount_ton", "price", "sold_price", "sale_price") or extract_price(merged))
                sold_at = extract_datetime(raw, "sold_at", "soldAt", "created_at", "createdAt", "date", "time") or now_utc()
                listed_at = extract_datetime(merged, "listed_at", "listedAt", "created_at", "createdAt")
                if not price:
                    continue
                seconds = int((sold_at - listed_at).total_seconds()) if listed_at else None
                records.append(
                    SaleRecord(
                        market=self.name,
                        gift_id=extract_id(merged),
                        collection=extract_collection(merged),
                        model=extract_model(merged),
                        symbol=extract_symbol(merged),
                        backdrop=extract_backdrop(merged),
                        sold_price_ton=price,
                        listed_at=listed_at,
                        sold_at=sold_at,
                        time_to_sell_seconds=seconds if seconds and seconds > 0 else None,
                        raw=raw,
                    )
                )
                if len(records) >= limit:
                    return records
            if records:
                return records
        return records

    async def get_floor_prices(self, *, collection: str, model: str | None = None) -> list[FloorRecord]:
        # Strong fallback: actual lowest active listing from search endpoint.
        try:
            listings = await self.search_listings(min_price=0, max_price=1_000_000, collection=collection, model=model, limit=20)
        except Exception as exc:
            logger.warning("MRKT floor fallback failed: %s", exc)
            return []
        if not listings:
            return []
        checked_at = datetime.now(timezone.utc)
        floors: list[FloorRecord] = []
        lowest = min(x.price_ton for x in listings)
        floors.append(FloorRecord(self.name, collection, model, None, None, lowest, checked_at))
        # Add trait-level floors for current items where possible.
        for listing in listings[:5]:
            floors.append(FloorRecord(self.name, listing.collection, listing.model, listing.symbol, listing.backdrop, listing.price_ton, checked_at))
        return floors
