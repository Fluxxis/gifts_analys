# Gift Arbitrage Bot MVP

Telegram бот для анализа NFT Gifts. Бот ищет лоты в диапазоне цены, считает риск, прибыль, скорость продажи, строит PNG график и дает ссылку на ручную покупку.

## Что уже реализовано

- aiogram 3 бот
- MRKT WebApp auth через Pyrogram и tgWebAppData
- MRKT `/gifts/saling`
- ввод диапазона цены
- inline карточки сделок
- SQLite база
- snapshots цен
- попытка сбора feed/sales, если endpoint доступен
- расчет прибыли, риска и confidence score
- PNG график цены
- watchlist
- админка статуса
- запуск на Ubuntu через start.sh и systemd

## Что честно не реализовано в MVP

- Автопокупка
- Автовыставление на продажу
- Полная интеграция Tonnel и Portals

Tonnel и Portals добавлены как адаптеры not_configured. Они не ломают бота. Для реальной работы нужно добавить их authData и методы конкретной библиотеки.

## Установка Ubuntu

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip git
chmod +x install.sh start.sh
./install.sh
nano config.json
./start.sh
```

## Настройка config.json

Заполни:

```json
"bot_token": "TOKEN_FROM_BOTFATHER",
"admin_ids": [7225974704],
"telegram_user": {
  "api_id": 123456,
  "api_hash": "YOUR_API_HASH",
  "session_name": "./data/sessions/market_user"
}
```

api_id и api_hash берутся на my.telegram.org.

При первом запуске Pyrogram попросит войти в Telegram аккаунт. Это нужно для MRKT Mini App авторизации.

Проверить MRKT токен отдельно:

```bash
./venv/bin/python scripts/generate_mrkt_token.py
```

## Systemd

Если проект лежит в `/opt/gift_arbitrage_bot`:

```bash
sudo cp gift_bot.service /etc/systemd/system/gift_bot.service
sudo systemctl daemon-reload
sudo systemctl enable gift_bot
sudo systemctl start gift_bot
sudo systemctl status gift_bot
journalctl -u gift_bot -f
```

## Команды в боте

- `/start` — меню
- кнопка `Найти выгодные гифты` — поиск
- кнопка `Watchlist` — создать правило отслеживания
- кнопка `Админка` — статус, только admin_ids

## Важно

Бот не обещает 100% прибыль. Он считает оценку по данным. Если нет истории продаж, бот снижает confidence score и пишет слабый вердикт. Это правильно. Иначе бот будет покупать неликвид по фейковому floor.
